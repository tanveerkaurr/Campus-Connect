/** @type {import('tailwindcss').Config} */

const withMT = require("@material-tailwind/react/utils/withMT");


module.exports = withMT({
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        "BgWhite": "#fff",
        "BgBlack": "#000",
        "BgLightBlack": "#e7e7e7",
        "ColorTextBlack": "#000",
        "ColorTextWhite": "#fff",
        "ColorTextGray": "#808080",
        "ColorTextBlue": "#349ff4",
      }
    },
  },
  plugins: [
  ],
});

/*

text
shadow
border   
background
hovering
buttons
links 

*/