import { BrowserRouter as Router, Route, Routes, useLocation } from "react-router-dom";
import {
    Dashstudent,
    ClubsAdmin,
    Profile,
    Notifications,
    Clubs,
    Error404,
    ManageNotifications
} from "./Containers";
import { NavbarDefault, Footer } from "./Components";
// import Header from "./Components/nav";
import Clubpage from "./Containers/Club-page";
import Clubpage_teacher from "./Containers/Club-page-teacher";
import Register from "./Containers/Register";
import { useState } from "react";
import Club from "./Containers/Club";
import Teacher_Clubs from "./Containers/Clubs-teacher";

function App() {
    return (
        <Router>
            <AppContent />
        </Router>
    );
}
function AppContent() {
    const location = useLocation();
    const navbarPage = location.pathname === "/register";
    const[login,setlogin]=useState(false);
    let role=localStorage.getItem("role");

    return (
        <>
            {!navbarPage && <NavbarDefault login={login} setlogin={setlogin}/>}
            <Routes>
                <Route path="/" element={<Dashstudent />} />
                <Route path="/club" element={ role==2 ? (< Teacher_Clubs />):(<Clubs/>)} /> 
           

                <Route path="/specific-club-Student" element={<Clubpage />} />   
                <Route path="/specific-club-teacher" element={<Clubpage_teacher />} />   
                {/* <Route path="/teacher_clubs" element={<Clubpage_teacher />} /> */}
                <Route path="/admin/addEvent" element={<ClubsAdmin />} />  {/* !Experimental for development only */}
                <Route path="/profile" element={<Profile />} />
                <Route path="/notifications" element={role==1 ? (<Notifications />):(<ManageNotifications />)} />
                <Route path="/specific-club-Student" element={<Clubpage />} />
                <Route path="/register" element={<Register />} />
                {/* <Route path="/admin/notifications" element={<ManageNotifications />} /> */}
                <Route path="/*" element={<Error404 />} />

            </Routes>
            {!navbarPage && <Footer />}
        </>
    );
}

export default App;
