import React from 'react'
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Slider from "react-slick";
import cpic from "../pics/MRSPTU-2.jpg"
import cpic1 from "../pics/MRSPTU-3.jpg"
import cpic2 from "../pics/gzscet2.jpg"

function Welcome_Carousel() {
    var settings = {
        dots: true,
        infinite: true,
        speed: 1000,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay:true,
        pauseOnHover: true,
        autoplaySpeed: 3000,
        cssEase: "linear",
      };
      return (
        <Slider {...settings} className='overflow-hidden m-4 rounded py-4'>
            <img src={cpic1} alt="Demo pic"></img>
            <img src={cpic2} alt="Demo pic"></img>
            <img src={cpic} alt="Demo pic"></img>
          
        </Slider>
      );
    }

export default Welcome_Carousel