import { Chip } from "@material-tailwind/react";
 
const ChipIcon=({text,alignment})=> {
  return (
    <div className = {`flex ${alignment}`}>
      <Chip
        variant="ghost"
        color="blue"
        size="sm"
        value={text}
        icon={
          <span className="mx-auto mt-1 block h-2 w-2 rounded-full bg-blue-900 content-['']" />
        }
      />
    </div>
  );
}

export default ChipIcon;