import {
  List,
  ListItem,
  ListItemSuffix,
  Card,
  ListItemPrefix
} from "@material-tailwind/react";
import {RemoveApplication} from "../Services/controllers/ApplicationController";
import swal from "sweetalert";



const ListCard = ({ data,next }) => {


  const handleRemoveApplication = async (applicationId) => {
    console.log(applicationId);
    let obj={
      applicationId:applicationId,
      action:"remove"
    }
    try{
      const response=await RemoveApplication(obj);
      if(response.data.success){
        console.log(response.data.message);

      }
      else{
        console.log(response.data.message);
      }

    }
    catch(err){
      console.log(err);
    }
    next();
  }

  return (
    <Card className="w-full h-full overflow-auto">
      <List className="">
        {data.map((item, index) => (
          <ListItem key={item._id} className="cursor-default border border-spacing-1">
            <ListItemPrefix>
              {index + 1}.
            </ListItemPrefix>
            {/* we want name that fits in the name block so that rest could be shown by ... */}
            <p className="text-ellipsis text-sm">{item.applicationTitle}</p>
            <ListItemSuffix>
              <svg xmlns="http://www.w3.org/2000/svg"
                fill="none" viewBox="0 0 24 24" strokeWidth={1.5}
                stroke="currentColor"
                className="w-6 h-6"
                onClick={() => {
                  swal({
                    title: "Are you sure?",
                    text: "Once deleted, you will not be able to recover this application!",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                  })
                    .then((willDelete) => {
                      if (willDelete) {
                        handleRemoveApplication(item._id);
                        swal("Your application has been deleted!", {
                          icon: "success",
                        });
                      } else {
                        swal("Your application is safe!");
                      }
                    });
                }}
              >
                <path strokeLinecap="round" strokeLinejoin="round" d="m9.75 9.75 4.5 4.5m0-4.5-4.5 4.5M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
              </svg>
            </ListItemSuffix>

          </ListItem>
        ))}
      </List>
    </Card>
  );
}

export default ListCard;

