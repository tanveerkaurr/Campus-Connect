import "react-multi-carousel/lib/styles.css";
import {
    Card,
    CardBody,
    CardFooter,
    Typography,
    Button,
} from "@material-tailwind/react";



export default function Slider({ data }) {
    return (
        <div className=" h-[100%]  bg-BgBlack mx-2 p-1 rounded-xl flex justify-center align-middle  ">
            <Card className="mt-2  gap-0">
                <CardBody>
                    <Typography variant="h5" color="black" className="mb-2 text-sm*2 m-0 p-0 md:m-1 md:p-1 text-ColorTextBlack">
                        {data.Name}
                    </Typography>
                    <Typography variant="p" className="text-sm">{data.description}</Typography>
                    <Typography variant="h6" className="text-sm">
                        <span className="text-ColorTextBlack">
                            Expected Package :-{" "}
                        </span>
                        {data.package}
                    </Typography>
                    <Typography variant="h6" className="text-sm">
                        <span className="text-ColorTextBlack">Deadline :- </span>
                        {data.last_date}
                    </Typography>
                </CardBody>
                <CardFooter className="m-1 p-0 px-2 flex justify-end">
                    <a href={data.ref_link}>
                        <Button variant="gradient" color="gray" className="text-xs">
                            Apply Now
                        </Button>
                    </a>
                </CardFooter>
            </Card>
        </div>
    );
}
