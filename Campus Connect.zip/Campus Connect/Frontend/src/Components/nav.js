import React, { useState } from "react";
import { Bars3BottomRightIcon, XMarkIcon } from "@heroicons/react/24/solid";
const Header = () => {

  let [open, setopen] = useState(false);
  return (
    <div className="w-full bg-black">
      <div className="md:flex items-center md:w-full justify-between py-4 md:px-10 px-7">
        {/*Logo section*/}
        <div className="font-bold text-2xl cursor-pointer flex items-center gap-1">
          <div className="rounded-full bg-white mx-2">
          <img src="https://www.mrsptu.ac.in/images/mrslogo.png" width={50} alt="user"></img>
          </div>
          <span className="text-white">Hi, Name</span>
        </div>
        {/* mobile menu icon */}
        <div
          onClick={() => setopen(!open)}
          className="w-7 h-7 right-8 top-6 cursor-pointer md:hidden text-white absolute"
        >
          {open ? (
            <XMarkIcon></XMarkIcon>
          ) : (
            <Bars3BottomRightIcon></Bars3BottomRightIcon>
          )}
        </div>
        {/* Nav Link item */}
        <ul
          className={`md:flex md:item-center md:pb-0 absolute md:static md:z-auto z-10 left-0 w-full md:w-auto mt-4 md:mt-0 md:pl-9 bg-slate-400 sm:bg-slate-400  md:bg-transparent transition-all duration-500 ease-in ${
            open ? "top-12" : "top-[-490px]"
          }`}
        >
          <li className="md:ml-8 md:my-0 my-7 font-semibold sm:flex-row">
            {/* {logedin ? ( */}
              <button
                className="text-white py-1 font-semibold me-3 pe-3 md:border-r-2"
                // onClick={DashboardHandler}
                >
                Home
              </button>
            {/* ) : ( */}
            <button
                className="text-white py-1 font-semibold me-3 pe-3 md:border-r-2"
                // onClick={logoutHandler}
              >
                Notification
              </button>
              <button
                className="text-white py-1 font-semibold me-3 pe-3 md:border-r-2"
                // onClick={signupHandler}
              >
                Clubs
              </button>
            {/* )} */}
            {/* {logedin ? */}
              
            {/* : */}
              <button
                className="text-white py-1 font-semibold me-3 pe-3 md:border-r-2"
                // onClick={loginHandler}
              >
                Profile
              </button>
              <button
                className="text-white py-1 font-semibold me-3 pe-3"
                // onClick={loginHandler}
              >
                Logout
              </button>
          </li>
        </ul>
      </div>
    </div>
  );
};

export default Header;
