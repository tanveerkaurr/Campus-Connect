import {
  Timeline,
  TimelineItem,
  TimelineConnector,
  TimelineHeader,
  TimelineIcon,
  TimelineBody,
  Typography,
} from "@material-tailwind/react";


const TimeLineCard=(data)=> {
  return (
      <div className="">
        <Timeline>
          {data.data.map((item,index) => (
            <TimelineItem>
            <TimelineConnector/>
            <TimelineHeader className="h-3">
              <TimelineIcon />
              <Typography variant="h6" color="blue-gray" className="leading-none">
              {item.clubName}
              </Typography>
            </TimelineHeader>
            <TimelineBody className="pb-8">
             
            </TimelineBody>
          </TimelineItem>
          ))}
          
        </Timeline>
      </div>
    );
  }

export default TimeLineCard;