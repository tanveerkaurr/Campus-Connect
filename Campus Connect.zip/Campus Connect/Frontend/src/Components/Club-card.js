import { Typography } from '@material-tailwind/react';
import React from 'react';
import { Link } from 'react-router-dom';
import swal from 'sweetalert';
import Clubs from '../Containers/Clubs-student';
import { UnfollowClub, FollowClub } from '../Services/controllers/ClubController';

function Club_card({ obj, follower, buttonVisible, role, fetchUserClubs}) {

  // console.log(role);
  return (
    <div className='border-2 my-6 md:mx-12 rounded-xl p-4'>
      <div className='mb-2 flex justify-between'>
        <div className='flex'>
          <img src={obj.clubImage} className="w-12" alt={obj.clubName}></img>
          <Typography variant='h5' className='mx-4 mt-3'>{obj.clubName}</Typography>
        </div>
        { buttonVisible ?
        (<div>
          {follower ? (
            <button
              className="align-middle font-sans font-bold text-center uppercase transition-all disabled:opacity-50 disabled:shadow-none disabled:pointer-events-none text-xs py-3 px-6 rounded-lg bg-gray-900 text-white shadow-md shadow-gray-900/10 hover:shadow-lg hover:shadow-gray-900/20 focus:opacity-[0.85] focus:shadow-none active:opacity-[0.85] active:shadow-none"
              type="button" onClick={async ()=>{
                const data = {
                  userId : localStorage.getItem("userId"),
                  clubId : obj._id
                }
                try{
                  // console.log(data);
                  const response = await UnfollowClub(data);
                  console.log(response);
                  swal({
                    title: "Unfollowed",
                    text: "You will not be able to recieve notifications from this club from now !!",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                  })
                  .then((willDelete) => {
                    if (willDelete) {
                      
                      window.location.reload();
                    } else {
                      swal("Refresh to reload the page");
                    }
                  });
                  // fetchUserClubs();
                }catch(err) {
                 console.log(err);
                 swal("Error", err.response.data.message || err.response.data.error, "error");
                }
              }}> Unfollow</button>
          ) : (
            <button
              className="align-middle font-sans font-bold text-center uppercase transition-all disabled:opacity-50 disabled:shadow-none disabled:pointer-events-none text-xs py-3 px-6 rounded-lg bg-gray-900 text-white shadow-md shadow-gray-900/10 hover:shadow-lg hover:shadow-gray-900/20 focus:opacity-[0.85] focus:shadow-none active:opacity-[0.85] active:shadow-none"
              type="button" onClick={async ()=>{
                const data = {
                  userId : localStorage.getItem("userId"),
                  clubId : obj._id
                }
                try{
                  console.log(data);
                  const response = await FollowClub(data);
                  console.log(response);
                  swal({
                    title: "Followed",
                    text: "You will now able to recieve notifications from this club from now !!",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                  })
                  .then((willDelete) => {
                    if (willDelete) {
                      
                      window.location.reload();
                    } else {
                      swal("Refresh to reload the page");
                    }
                  });
                }catch(err) {
                 console.log(err);
                 swal("Error", err.response.data.message || err.response.data.error, "error");
                }
              }} > Follow</button>
          )}
        </div>)
          :
          (<div>

          </div>)
        }
      </div>
      <hr></hr>
      <div className='mb-2 flex justify-between'>
        <div className='flex ms-4'>
          <Typography variant='paragraph' className='mx-4 mt-3'>{obj.clubDescription}</Typography>
        </div>
        <div>
          {role=="1" ? (<Link to={"/specific-club-Student"}
            className="align-middle font-sans font-bold text-center uppercase transition-all disabled:opacity-50 disabled:shadow-none disabled:pointer-events-none text-xs py-3 px-6 rounded-lg bg-gray-900 text-white shadow-md shadow-gray-900/10 hover:shadow-lg hover:shadow-gray-900/20 focus:opacity-[0.85] focus:shadow-none active:opacity-[0.85] active:shadow-none mt-3"
            type="button" onClick={(()=>{
              localStorage.setItem("ClubId",obj._id)
            })}> Read more</Link>):
            (<Link to={"/specific-club-teacher"}
            className="align-middle font-sans font-bold text-center uppercase transition-all disabled:opacity-50 disabled:shadow-none disabled:pointer-events-none text-xs py-3 px-6 rounded-lg bg-gray-900 text-white shadow-md shadow-gray-900/10 hover:shadow-lg hover:shadow-gray-900/20 focus:opacity-[0.85] focus:shadow-none active:opacity-[0.85] active:shadow-none mt-3"
            type="button" onClick={(()=>{
              localStorage.setItem("ClubId",obj._id)
            })}> Read more</Link>)}
        </div>
      </div>
    </div>
  );
}

export default Club_card;
