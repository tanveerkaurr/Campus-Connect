import React from "react";
import {
    Button,
    Dialog,
    Card,
    CardBody,
    CardFooter,
    Typography,
    Input,
} from "@material-tailwind/react";
import swal from 'sweetalert';

import { AddApplication,UpdateApplication } from "../../Services/controllers/ApplicationController";
// import {AddNotification} from "../../Services/controllers/NotificationController";

import { useRef, useState } from "react";

export default function AddApplicationModal({ handleOpen, open, setOpen,
    EditorData = {
        applicationType: 3,
        applicationTitle: "",
        companyName: "",
        companyAddress: "",
        companyWebsite: "",
        companyContact: "",
        requiredSkills: [],
        applicationDescription: "",
        applicationDuration: "",
        applicationStartDate: "",
        applicationDeadline: "",
        applicationLink: ""
    }, Edit = false,setEditData
}) {
    // if clicked outside, close the dialog
    const dialogRef = useRef();

    const [data, setData] = useState(EditorData);


    // clubName, clubDescription, clubType, clubHeadContact , clubHeadName


    const ApplicationTypes = ["Internship", "Job", "Training", "Workshop"];


    // title, message, type, link


    const handleSubmit = async () => {
        try {
            const resp = await AddApplication(data);
            if (resp.data.success) {
                swal("Success", "Application added successfully", "success");
            }
            else {
                swal("Error", "Something went wrong", "error");
            }

        }
        catch (err) {
            console.log(err);
        }




        handleOpen();
    }


    const handleEdit = async () => {
        try {
            data.id=data._id;
            const resp = await UpdateApplication(data);
            if (resp.data.success) {
                swal("Success", "Application Updated successfully", "success");

            }
            else {
                swal("Error", "Something went wrong", "error");
            }

        }
        catch (err) {
            console.log(err);
        }
        setEditData({});
        handleOpen();
    }


    return (
        <>
            <Dialog
                ref={dialogRef}
                size="xs"
                open={open}
                handler={handleOpen}
                className="bg-transparent shadow-none max-h-full overflow-scroll"

            >
                <Card className="mx-auto w-full max-w-[32rem]">
                    <CardBody className="flex flex-col gap-4">


                        <Typography variant="h4" color="blue-gray">
                            New Application
                        </Typography>
                        <Typography
                            className="mb-3 font-normal"
                            variant="paragraph"
                            color="gray"
                        >
                            Fill in the form below to create a new Application.
                        </Typography>

                        <Typography className="-mb-2" variant="h6">
                            Application Type
                        </Typography>

                        <div className=" flex justify-between flex-wrap">
                            {/* i want index and option both */}
                            {ApplicationTypes.map((option) => (
                                <label key={option} className="flex items-center ">
                                    <input
                                        label={option}
                                        value={option}
                                        type="radio"
                                        size="lg"

                                        checked={ApplicationTypes[data.applicationType] === option}
                                        onChange={(e) => {
                                            setData({ ...data, applicationType: ApplicationTypes.findIndex((type) => { return type === option }) })
                                        }}
                                    />
                                    <span className="ml-2">{option}</span>
                                </label>
                            ))}
                        </div>


                        <Typography className="-mb-2" variant="h6">
                            Application Title
                        </Typography>
                        <Input label="title" size="lg"
                            value={data.applicationTitle}
                            onChange={(e) => {
                                setData({ ...data, applicationTitle: e.target.value })
                            }} />


                        <Typography className="-mb-2" variant="h6">
                            Company Name
                        </Typography>
                        <Input label="company"
                            type="text" size="lg"
                            value={data.companyName}
                            onChange={(e) => {
                                setData({ ...data, companyName: e.target.value })

                            }} />


                        <Typography className="-mb-2" variant="h6">
                            Company Address
                        </Typography>
                        <Input label="address" type="text" size="lg"
                            value={data.companyAddress}
                            onChange={(e) => {
                                setData({ ...data, companyAddress: e.target.value })
                            }} />

                        <Typography className="-mb-2" variant="h6">
                            Company Website
                        </Typography>
                        <Input label="website" type="text" size="lg"
                            value={data.companyWebsite}
                            onChange={(e) => {
                                setData({ ...data, companyWebsite: e.target.value })
                            }} />

                        <Typography className="-mb-2" variant="h6">
                            Company Contact
                        </Typography>
                        <Input label="contact" type="text" size="lg"
                            value={data.companyContact}
                            onChange={(e) => {
                                setData({ ...data, companyContact: e.target.value })
                            }} />


                        <Typography className="-mb-2" variant="h6">
                            Required Skills
                        </Typography>
                        <Input label="skills" type="text" size="lg"
                            value={data.requiredSkills}
                            onChange={(e) => {
                                setData({ ...data, requiredSkills: e.target.value })
                            }} />




                        <Typography className="-mb-2" variant="h6">
                            Application Description
                        </Typography>
                        <Input label="description" type="text" size="lg"
                            value={data.applicationDescription}
                            onChange={(e) => {
                                setData({ ...data, applicationDescription: e.target.value })
                            }} />


                        <Typography className="-mb-2" variant="h6">
                            Application Duration (in days)
                        </Typography>
                        <Input label="duration" type="text" size="lg"
                            value={data.applicationDuration}
                            onChange={(e) => {
                                setData({ ...data, applicationDuration: e.target.value })
                            }} />


                        <Typography className="-mb-2" variant="h6">
                            Application Start Date
                        </Typography>
                        <Input label="start date" type="date" size="lg"
                            value={data.applicationStartDate}
                            onChange={(e) => {
                                setData({ ...data, applicationStartDate: e.target.value })
                            }} />



                        <Typography className="-mb-2" variant="h6">
                            Application Deadline
                        </Typography>
                        <Input label="deadline" type="date" size="lg"
                            value={data.applicationDeadline}
                            onChange={(e) => {
                                setData({ ...data, applicationDeadline: e.target.value })
                            }} />


                        <Typography className="-mb-2" variant="h6">
                            Application Link
                        </Typography>
                        <Input label="link" type="text" size="lg"
                            value={data.applicationLink}
                            onChange={(e) => {
                                setData({ ...data, applicationLink: e.target.value })
                            }} />


                    </CardBody>
                    <CardFooter className="pt-0">
                        {Edit ? (
                            <Button variant="gradient" onClick={handleEdit} fullWidth>
                                Edit Application
                            </Button>
                        ) : (
                            <Button variant="gradient" onClick={handleSubmit} fullWidth>
                                Add Application
                            </Button>
                        )}

                    </CardFooter>
                </Card>
            </Dialog>
        </>
    );
}