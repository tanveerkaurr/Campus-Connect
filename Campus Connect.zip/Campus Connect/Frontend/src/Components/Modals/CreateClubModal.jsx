import React from "react";
import {
    Button,
    Dialog,
    Card,
    CardHeader,
    CardBody,
    CardFooter,
    Typography,
    Input,
    Checkbox,
} from "@material-tailwind/react";
import { useRef, useState } from "react";
import { Add_Club,ClubUpdateController } from "../../Services/controllers/ClubController";
import swal from 'sweetalert'

export default function CreateClubModal(
    { handleOpen, open, setOpen,
        EditInfo = {
            clubName: "",
            clubDescription: "",
            clubType: "",
            clubHeadContact: "",
            clubHeadName: "",
            clubImg: ""
        }, toEdit = false, CTA
    }
) {
    // if clicked outside, close the dialog
    const dialogRef = useRef();
    
    console.log(EditInfo)

    const [data, setData] = useState(EditInfo);
    // console.log(data)

    const [previewImage, setPreviewImage] = useState(EditInfo.clubImage);

    // clubName, clubDescription, clubType, clubHeadContact , clubHeadName


    const NotificationTypes = ["Departmental", "University"];


    // title, message, type, link


    const handleSubmit = async () => {
        
        var formdata = new FormData();
        for (var prop in data) {
            formdata.append(prop, data[prop]);
        }
        try {
            // console.log(data);
            const serverMsg = await Add_Club(formdata, {
                headers: { "Content-Type": "multipart/form-data" },
            });
            console.log(serverMsg);
            if (serverMsg.data.success === true) {
                
                swal("New club Created!", "Club is created have been saved successfully!", "success");
            }
        } catch (err) {
            console.log(err)
            swal("Error", err.response.data.message || err.response.data.error, "error");
        }

        handleOpen();
    }

    const handleUpdate = async () => {

        var formdata = new FormData();
        for (var prop in data) {
            formdata.append(prop, data[prop]);
        }

        formdata.append("clubId", data._id);

        const response = await ClubUpdateController(formdata, {
            headers: { "Content-Type": "multipart/form-data" },
        });

        // console.log(response);


        if (response.data.success === true) {
            swal("Club Updated!", "Club has been updated successfully!", "success");
        }
        else {
            swal("Error", response.data.message || response.data.error, "error");
        }

        handleOpen();
        CTA();

    }



    return (
        <>
            <Dialog
                ref={dialogRef}
                size="xs"
                open={open}
                handler={handleOpen}
                className="bg-transparent shadow-none max-h-full overflow-scroll"

            >
                <Card className="mx-auto w-full max-w-[24rem]">
                    <CardBody className="flex flex-col gap-4">
                        <Typography variant="h4" color="blue-gray">
                            {toEdit ? "Edit Club" : "Create Club"}
                        </Typography>
                        <Typography
                            className="mb-3 font-normal"
                            variant="paragraph"
                            color="gray"
                        >
                            Fill in the form below to {toEdit ? "edit" : "create"} a  club.
                        </Typography>

                        <div className="w-48 m-1 p-1">
                            <label class="block mb-2 text-sm font-medium text-gray-900 dark:text-white" for="file_input">Upload Icon Image</label>
                            <input
                                className="block w-full text-sm text-gray-900 border border-gray-300 rounded-lg cursor-pointer bg-gray-50 dark:text-gray-400 focus:outline-none dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400"
                                id="file_input"
                                type="file"
                                onChange={(e) => {
                                    const file = e.target.files[0];
                                    if (file) {
                                        setData({ ...data, clubImg: e.target.files[0] })
                                        // console.log((e.target.files[0]))
                                        const reader = new FileReader();
                                        reader.onload = (e) => {
                                            setPreviewImage(e.target.result);
                                        };
                                        reader.readAsDataURL(file);
                                    }
                                }}

                            >
                            </input>
                            <img src={previewImage} alt="preview" className="w-10 h-10" />

                        </div>

                        <Typography className="-mb-2" variant="h6">
                            Club Name
                        </Typography>
                        <Input label="name" size="lg"
                            value={data.clubName}
                            onChange={(e) => {
                                setData({ ...data, clubName: e.target.value })
                            }} />


                        <Typography className="-mb-2" variant="h6">
                            Club Description
                        </Typography>
                        <Input label="description"
                            type="text" size="lg"
                            value={data.clubDescription}
                            onChange={(e) => {
                                setData({ ...data, clubDescription: e.target.value })

                            }} />
                        <Typography className="-mb-2" variant="h6">
                            Club Type
                        </Typography>

                        <div className=" flex justify-between flex-wrap">

                            {NotificationTypes.map((option) => (
                                <label key={option} className="flex items-center ">
                                    <input
                                        label={option}
                                        value={option}
                                        type="radio"
                                        size="lg"
                                        checked={data.clubType == option?true:false}
                                        onChange={(e) => {
                                            setData({ ...data, clubType: e.target.value })
                                        }}
                                    />
                                    <span className="ml-2">{option}</span>
                                </label>
                            ))}
                        </div>

                        <Typography className="-mb-2" variant="h6">
                            Club Head Name
                        </Typography>
                        <Input label="head-name" type="text" size="lg"
                            value={data.clubHeadName}
                            onChange={(e) => {
                                setData({ ...data, clubHeadName: e.target.value })
                            }} />

                        <Typography className="-mb-2" variant="h6">
                            Club Head Contact
                        </Typography>
                        <Input label="contact" type="text" size="lg"
                            value={data.clubHeadContact}
                            onChange={(e) => {
                                setData({ ...data, clubHeadContact: e.target.value })
                            }} />


                    </CardBody>
                    <CardFooter className="pt-0">
                        {toEdit ? (
                            <Button variant="gradient" onClick={handleUpdate} fullWidth>
                                Update Club
                            </Button>
                        )
                            :
                            (
                                <Button variant="gradient" onClick={handleSubmit} fullWidth>
                                    Add Club
                                </Button>
                            )}

                    </CardFooter>
                </Card>
            </Dialog>
        </>
    );
}