
import { PhotoIcon, UserCircleIcon } from '@heroicons/react/24/solid';
import {useState} from 'react'

export default function EventModal() {
  const clubs = ['Club 1', 'Club 2', 'Club 3', 'Club 4', 'Club 5'];

  const [event, setEvent] = useState({
    clubId:"",  //object Id
    eventName:"",
    eventDescription:"",
    eventDate:"",
    eventTime:"",
    eventVenue:"",
    eventHeadName:"",
    eventHeadContact:"",
    eventLink:""
  })

  // possible clubs

  return (
    <div className='m-4 p-4 w-1/2 min-w-72'>
      <h2 className="text-lg font-semibold leading-7 text-gray-900">Add Event</h2>
      <p className="mt-1 text-sm leading-6 text-gray-600">
        Insert the event details here.
      </p>

      {/* add dropdown box to do options of the clubs possible */}
      <div className="mt-10 grid grid-cols-1 gap-x-6 gap-y-8 sm:grid-cols-6">
            <div className="sm:col-span-4">
              <label htmlFor="club-name" className="block text-sm font-medium leading-6 text-gray-900">
                Club Name
              </label>
              <div className="mt-2">
                <select
                  id="club-name"
                  name="club-name"
                  autoComplete="given-name"
                  onChange={(e)=>setEvent({...event, clubId: e.target.value})}
                  value={event.clubId}
                  className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6"
                >
                  {clubs.map((club, index) => (
                    <option key={index} value={club}>{club}</option>
                  ))}
                </select>
              </div>
            </div>
          </div>

      <div className="space-y-12">
          <div className="mt-10 grid grid-cols-1 gap-x-6 gap-y-8 sm:grid-cols-6">
            <div className="sm:col-span-4">
              <label htmlFor="event-name" className="block text-sm font-medium leading-6 text-gray-900">
                Event Name
              </label>
              <div className="mt-2">
                <input
                  type="text"
                  name="event-name"
                  id="event-name"
                  autoComplete="given-name"
                  value={event.eventName}
                  onChange={(e)=>setEvent({...event, eventName: e.target.value})}
                  className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6"
                />
              </div>
            </div>

            <div className="sm:col-span-4">
              <label htmlFor="event-description" className="block text-sm font-medium leading-6 text-gray-900">
                Event Description
              </label>
              <div className="mt-2">
                <textarea
                  name="event-description"
                  id="event-description"
                  autoComplete="given-description"
                  onChange={(e)=>setEvent({...event, eventDescription: e.target.value})}
                  rows={3}
                  value={event.eventDescription}
                  className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6"
                />
              </div>
            </div>

          </div>

          <div className="mt-10 grid grid-cols-1 gap-x-6 gap-y-8 sm:grid-cols-6">
            <div className="sm:col-span-4">
              <label htmlFor="event-date" className="block text-sm font-medium leading-6 text-gray-900">
                Event Date
              </label>
              <div className="mt-2">
                <input

                  type="date"
                  name="event-date"
                  id="event-date"
                  value={event.eventDate}
                  autoComplete="given-date"
                  onChange={(e)=>setEvent({...event, eventDate: e.target.value})}
                  className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6"
                />
              </div>
            </div>

            <div className="sm:col-span-4">
              <label htmlFor="event-time" className="block text-sm font-medium leading-6 text-gray-900">

                Event Start Time
              </label>
              <div className="mt-2">
                <input
                  type="time"
                  name="event-time"
                  id="event-time"
                  value={event.eventTime}
                  autoComplete="given-time"
                  onChange={(e)=>setEvent({...event, eventTime: e.target.value})}
                  className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6"
                />
              </div>
            </div>

          </div>
        

        <div className="border-b border-gray-900/10 pb-12">
         

          <div className="my-6 space-y-4">
            
            <div className="flex items-center justify-between">

              <div className="flex items-center">
                <UserCircleIcon className="h-6 w-6 text-gray-400"  />
                <span className="ml-4 text-sm font-semibold text-gray-900">Event Venue</span>
                </div>
              <div className="flex items-center">
                <input
                  id="event-venue"
                  name="event-venue"
                  type="text"
                  value={event.eventVenue}
                  onChange={(e)=>setEvent({...event, eventVenue: e.target.value})}
                  className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6"
                />
                </div>
                </div>

          </div>

          <div className="my-6 space-y-4">
            
            <div className="flex items-center justify-between">

              <div className="flex items-center">
                <UserCircleIcon className="h-6 w-6 text-gray-400"  />
                <span className="ml-4 text-sm font-semibold text-gray-900">Event Head Contact</span>
                </div>
              <div className="flex items-center">
                <input
                  id="event-headcontact"
                  name="event-headcontact"
                  type="text"
                  value={event.eventHeadContact}
                  onChange={(e)=>setEvent({...event, eventHeadContact: e.target.value})}
                  className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6"
                />
                </div>
                </div>

          </div>

          <div className="sm:col-span-4">
              <label htmlFor="event-link" className="block text-sm font-medium leading-6 text-gray-900">
                Event Link
              </label>
              <div className="mt-2">
                <input
                  type="text"
                  name="event-link"
                  id="event-link"
                  value={event.eventLink}
                  autoComplete="given-link"
                  onChange={(e)=>setEvent({...event, eventLink: e.target.value})}
                  className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6"
                />
              </div>
            </div>


        </div>
      </div>

      <div className="mt-6 flex items-center justify-end gap-x-6">
        <button type="button" className="text-sm font-semibold leading-6 text-gray-900">
          Cancel
        </button>
        <button
        onClick={()=>console.log(event)}
          className="rounded-md bg-indigo-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
        >
          Save
        </button>
      </div>
    </div>
  )
}


/*
    clubId: {
        type: String,
        required: true
    },


*/