import React from "react";
import {
    Button,
    Dialog,
    Card,
    CardHeader,
    CardBody,
    CardFooter,
    Typography,
    Input,
    Checkbox,
} from "@material-tailwind/react";
import { useRef, useState } from "react";
import swal from "sweetalert";
import {AddNotification} from "../../Services/controllers/NotificationController";

export default function AddNotificationModal({ handleOpen, open, setOpen, EditData = {
    id: "",
    title: "",
    message: "",
    type: "",
    link: ""
}, CTA,setEditData }) {
    
    // if clicked outside, close the dialog
    const dialogRef = useRef();

    const [data, setData] = useState(EditData);

    const NotificationTypes = ["Club", "General"];


    // title, message, type, link


    const handleSubmit = async () => {
        try{
            data.id=data._id;
            const res = await CTA(data);
            // console.log(res);
            if(res.data.success){
                swal("Success", "Notification added successfully", "success");
            }
            else{
                swal("Error", "Something went wrong", "error");
            }
        }
        catch(err){
            console.log(err);
        }
        setEditData({});
        handleOpen();

    }


    return (
        <>
            <Dialog
                ref={dialogRef}
                size="xs"
                open={open}
                handler={handleOpen}
                className="bg-transparent shadow-none max-h-full overflow-scroll"

            >
                <Card className="mx-auto w-full max-w-[32rem]">
                    <CardBody className="flex flex-col gap-4">
                        <Typography variant="h4" color="blue-gray">
                            New Notification
                        </Typography>
                        <Typography
                            className="mb-3 font-normal"
                            variant="paragraph"
                            color="gray"
                        >
                            Fill in the form below to create a new notification.
                        </Typography>
                        <Typography className="-mb-2" variant="h6">
                            Title
                        </Typography>
                        <Input label="title" size="lg"
                            value={data.title}
                            onChange={(e) => {
                                setData({ ...data, title: e.target.value })
                            }} />
                        <Typography className="-mb-2" variant="h6">
                            Message
                        </Typography>
                        <Input label="message" 
                        type="text" size="lg"
                        value={data.message}
                         onChange={(e) => {
                            setData({ ...data, message: e.target.value })

                        }} />
                        <Typography className="-mb-2" variant="h6">
                            Notification Type
                        </Typography>

                        <div className=" flex justify-between flex-wrap">

                            {NotificationTypes.map((option) => (
                                <label key={option} className="flex items-center ">
                                    <input
                                        label={option}
                                        value={option}
                                        type="radio"
                                        size="lg"

                                        checked={data.type === option}
                                        onChange={(e) => {
                                            setData({ ...data, type: e.target.value })
                                        }}
                                    />
                                    <span className="ml-2">{option}</span>
                                </label>
                            ))}
                        </div>

                        <Typography className="-mb-2" variant="h6">
                            Link on Click
                        </Typography>
                        <Input label="link" type="text" size="lg" 
                        value={data.link}
                        onChange={(e) => {
                            setData({ ...data, link: e.target.value })

                        }} />


                    </CardBody>
                    <CardFooter className="pt-0">
                        <Button variant="gradient" onClick={handleSubmit} fullWidth>
                            {EditData.title ? "Update Notification" : "Add Notification"}
                        </Button>

                    </CardFooter>
                </Card>
            </Dialog>
        </>
    );
}