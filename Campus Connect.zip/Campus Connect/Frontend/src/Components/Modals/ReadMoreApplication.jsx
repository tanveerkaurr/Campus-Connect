import React from "react";
import {
    Button,
    Dialog,
    DialogHeader,
    DialogBody,
    DialogFooter,
    Typography,
} from "@material-tailwind/react";
import { useState } from "react";
import { ApplyApplication } from "../../Services/controllers/ApplicationController";
import swal from "sweetalert";

export default function ReadMoreApplication(props) {
    // console.log(props)

    //   const [open, setOpen] = useState(true);
    const data = props.fullLengthData;
    // console.log(data)

    /*
    applicationDeadline    :     "2024-05-25T00:00:00.000Z",
    applicationDescription    :     "Just apply and leave the college"
    applicationDuration    :     "10000"
    applicationLink    :    "www.google.com"
    applicationStartDate    :     "2024-06-01T00:00:00.000Z"
    applicationTitle    :    "Application New 2"
    applicationType    :    2
    companyAddress    :    "San Fransisco"
    companyContact    :    "1234567890"
    companyName    :    "Google Inc."
    companyWebsite    :    "www.google.com"
    postedOn    :    "2024-05-19T08:02:21.012Z"
    requiredSkills    :    ['10th Pass']
    
    */

    const handleOpen = () => props.setOpen(!props.open);

    const handleApply = async () => {
        const obj = {
            applicationId: data._id,
            action: "add",
        };

        try {
            const res = await ApplyApplication(obj);
            if (res.data.success) {                
                if(data.applicationLink){
                    swal("Success", "Kindly fill the respective form for further processing", "success");
                    window.open(data.applicationLink, "_blank")
                }
                else{
                    swal("Success", "You have successfully applied for the application", "success");
                }
            }
            else {
                swal("Warning", "You can only apply once for an application", "warning");
            }
        }
        catch (err) {
            console.log(err)
            swal("Warning", "You can only apply once for an application", "warning");
        }
        handleOpen()
    }

    return (
        <>
            <Dialog
                open={props.open}

            >
                <DialogHeader>
                    <Typography variant="h5" color="blue-gray">
                        Your Attention is Required!
                    </Typography>
                </DialogHeader>
                <DialogBody divider className="grid place-items-center gap-2">
                    <svg
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 24 24"
                        fill="currentColor"
                        className="h-12 w-12 text-red-500"
                    >
                        <path
                            fillRule="evenodd"
                            d="M5.25 9a6.75 6.75 0 0113.5 0v.75c0 2.123.8 4.057 2.118 5.52a.75.75 0 01-.297 1.206c-1.544.57-3.16.99-4.831 1.243a3.75 3.75 0 11-7.48 0 24.585 24.585 0 01-4.831-1.244.75.75 0 01-.298-1.205A8.217 8.217 0 005.25 9.75V9zm4.502 8.9a2.25 2.25 0 104.496 0 25.057 25.057 0 01-4.496 0z"
                            clipRule="evenodd"
                        />
                    </svg>
                    <Typography color="red" variant="h5" className="text-sm md:text-lg">
                        Before Applying Read the following details carefully
                    </Typography>

                    <Typography color="blue-gray" variant="body1" className="text-sm md:text-lg">
                        Application Title : {data.applicationTitle}
                    </Typography>
                    <Typography color="blue-gray" variant="body1" className="text-sm md:text-lg">
                        Application Description : {data.applicationDescription}
                    </Typography>
                    <Typography color="blue-gray" variant="body1" className="text-sm md:text-lg">
                        Company Name : {data.companyName}
                    </Typography>
                    <Typography color="blue-gray" variant="body1" className="text-sm md:text-lg">
                        Company Address :  {data.companyAddress}
                    </Typography>
                    <Typography color="blue-gray" variant="body1" className="text-sm md:text-lg">
                        Company Contact : {data.companyContact}
                    </Typography>
                    <Typography color="blue-gray" variant="body1" className="text-sm md:text-lg">
                        Company Website : <a href={data.companyWebsite} target="_blank" rel="noreferrer" className="text-ColorTextBlue">{data.companyWebsite}</a>
                    </Typography>
                    <Typography color="blue-gray" variant="body1" className="text-sm md:text-lg">
                        Application Link :  <a href={data.applicationLink} target="_blank" rel="noreferrer" className="text-ColorTextBlue">{data.applicationLink}</a>
                    </Typography>
                    <Typography color="blue-gray" variant="body1" className="text-sm md:text-lg">
                        Date of Joining : {data.applicationStartDate.split("T")[0]}
                    </Typography>
                    <Typography color="blue-gray" variant="body1" className="text-sm md:text-lg">
                        Application Deadline : {data.applicationDeadline.split("T")[0]}
                    </Typography>
                    <Typography color="blue-gray" variant="body1" className="text-sm md:text-lg">
                        Duration  : {data.applicationDuration} days
                    </Typography>
                    <Typography color="blue-gray" variant="body1" className="text-sm md:text-lg">
                        Skills required : {data.requiredSkills}
                    </Typography>




                </DialogBody>

                <DialogFooter className="space-x-2">
                    <Button variant="text" color="blue-gray" onClick={handleOpen}>
                        Cancel
                    </Button>
                    <Button variant="gradient" onClick={() => {
                        handleApply()

                    }}
                        className="bg-gradient-to-r from-light-blue-500 to-blue-500 hover:from-light-blue-700 hover:to-blue-700"
                    >
                        Ok, Got it
                    </Button>
                </DialogFooter>
            </Dialog>
        </>
    );
}