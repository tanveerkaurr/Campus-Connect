import React from "react";
import {
  Button,
  Dialog,
  Card,
  CardHeader,
  CardBody,
  CardFooter,
  Typography,
  Input,
  Checkbox,
} from "@material-tailwind/react";
import { useRef,useState } from "react";
import { LoginController } from "../../Services/controllers/EntryController";
import { useNavigate } from 'react-router-dom';
import swal from "sweetalert";

 
export function DialogWithForm({handleOpen,open,setOpen,login,setlogin}) {
    // if clicked outside, close the dialog
    const dialogRef = useRef();
    const navigate = useNavigate();
    const [data, setData] = useState({
        email: "",
        password: "",
    });


    const handleSubmit = async () => {
    // console.log(data);
    
    try{
      const response= await LoginController(data)
      // console.log(response);
      if(response.data.success===true){
        localStorage.setItem("token",response.data.token);
        localStorage.setItem("userId",response.data.user._id);
        localStorage.setItem("role",response.data.user.role);
        localStorage.setItem("email",response.data.user.email);
        localStorage.setItem("name",response.data.user.name);
        setlogin(true);
        // localStorage.setItem("userInfo",{
        //   userId:response.data.user._id,
        //   role:response.data.user.role,
        //   email:response.data.user.email
        // })
        navigate("/profile")

      }
    }catch(err){
      console.log(err)
      swal("Error",err.response.data.message||err.response.data.error, "error");
    }
    
    handleOpen();
    }




 
  return (
    <>
      <Dialog
        ref={dialogRef}
        size="xs"
        open={open}
        handler={handleOpen}
        className="bg-transparent shadow-none"

      >
        <Card className="mx-auto w-full max-w-[24rem]">
          <CardBody className="flex flex-col gap-4">
            <Typography variant="h4" color="blue-gray">
              Log In
            </Typography>
            <Typography
              className="mb-3 font-normal"
              variant="paragraph"
              color="gray"
            >
              Enter your Email and password to Login
            </Typography>
            <Typography className="-mb-2" variant="h6">
              Your Email
            </Typography>
            <Input label="Email" size="lg" onChange={(e)=>{
                setData({...data,email:e.target.value})
            }}/>
            <Typography className="-mb-2" variant="h6">
              Your Password
            </Typography>
            <Input label="Password" type="password" size="lg" onChange={(e)=>{
                setData({...data,password:e.target.value})
            
            }}/>
           
          </CardBody>
          <CardFooter className="pt-0">
            <Button variant="gradient" onClick={handleSubmit} fullWidth>
              Log In
            </Button>
            <Typography variant="small" className="mt-4 flex justify-center">
              Don&apos;t have an account?
              <Typography
                as="a"
                href="/register"
                variant="small"
                color="blue-gray"
                className="ml-1 font-bold"
                onClick={(()=>{
                    setOpen(false);
                })}
              >
                Sign up
              </Typography>
            </Typography>
          </CardFooter>
        </Card>
      </Dialog>
    </>
  );
}