import {
    Tabs,
    TabsHeader,
    TabsBody,
    Tab,
    TabPanel,
    Typography
} from "@material-tailwind/react";
import {
    Card,
    CardHeader,
    CardBody,
    CardFooter,
    Avatar,
    Tooltip,
} from "@material-tailwind/react";
import { useState, useEffect } from "react";

import {FetchNotifications} from "../Services/controllers/NotificationController";


const NotificationGrid =()=>{
    const [data, setData] = useState([
        {
            label: "MRSPTU",
            value: "MRSPTU",
            params: [
                {
                    imageLink:
                        "https://images.unsplash.com/photo-1682407186023-12c70a4a35e0?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2832&q=80",
                    title: "Slow life",
                    description: "Slow life is a lifestyle that emphasizes a slower approach to aspects of everyday life.",
                    date: "April 20, 2024"
                },
            ],
        },
        {
            label: "Student Clubs",
            value: "Student Clubs",
            params: [
                {
                    imageLink:
                        "https://images.unsplash.com/photo-1682407186023-12c70a4a35e0?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2832&q=80",
                    title: "Marvel Assembly",
                    description: "You are being called by Cheif so reach Headquaters as soon as possible",
                    date: "April 20, 2024"
                }
                
            ],
        }
    ])

    useEffect(() => {
        handleDataFetch();
    }, []);


    const handleDataFetch = async () => {
        const response = await FetchNotifications();

        if(response.data.success){
            const eachNotificationGeneral=response.data.notifications.map((notification)=>{
                // link,message,title,type
                if(notification.type==="General"){
                return{
                    imageLink:"https://images.unsplash.com/photo-1682407186023-12c70a4a35e0?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2832&q=80",
                    title:notification.title,
                    description:notification.message,
                    date:notification.link
                }

            }
            })
            const eachNotificationRest=response.data.notifications.map((notification)=>{
                // link,message,title,type
                if(notification.type!=="General"){
                return{
                    imageLink:"https://images.unsplash.com/photo-1682407186023-12c70a4a35e0?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2832&q=80",
                    title:notification.title,
                    description:notification.message,
                    date:notification.link
                }
            }
            })

            // we only need no-undefined data
            const filteredGeneral=eachNotificationGeneral.filter((notification)=>notification!==undefined);
            const filteredRest=eachNotificationRest.filter((notification)=>notification!==undefined);

            // console.log(eachNotificationGeneral);
            // console.log(eachNotificationRest);
            // console.log(filteredGeneral);
            // console.log(filteredRest);

            setData([
                {
                    label: "MRSPTU",
                    value: "MRSPTU",
                    params: filteredGeneral
                },
                {
                    label: "Student Clubs",
                    value: "Student Clubs",
                    params: filteredRest
                }
            ])
        }
        console.log(response);
    }

    return (
        <Tabs className="m-4" value={"MRSPTU"}>
            <TabsHeader className="flex justify-center align-middle bg-gray-50">
                {data.map(({ label, value }) => (
                    <Tab key={value} value={value} className="h-full max-w-96 bg-gray-300 rounded">
                        <Typography variant="p" className="h-full">{label}</Typography>
                    </Tab>
                ))}
            </TabsHeader>
            <TabsBody className="grid grid-cols-1 gap-4 ">
                {data.map(({ value, params }) => (
                    <TabPanel
                        className="flex justify-center align-middle flex-wrap gap-4"
                        key={value}
                        value={value}
                    >
                        {params?.map(({ imageLink, title, description, date }, index) => (
                            <div key={index}>
                                <BlogCard
                                    imageLink={imageLink}
                                    title={title}
                                    description={description}
                                    date={date}
                                ></BlogCard>
                            </div>
                        ))}
                    </TabPanel>
                ))}
            </TabsBody>
        </Tabs>
    );
}


const BlogCard = ({ imageLink, title, description, date }) => {
    return (
        <Card className="overflow-hidden max-w-96 hover:shadow-xl hover:shadow-gray-500">
            <CardHeader
                floated={false}
                shadow={false}
                color="transparent"
                className="m-0 rounded-none"
            >
                <img
                    src={imageLink}
                    alt="Slow life"
                />
            </CardHeader>
            <CardBody className="m-1 p-1">
                <Typography variant="p" color="blue-gray" className="font-bold text-md sm:text-lg m-0 p-0" >
                    {title}
                </Typography>
                <Typography variant="p" color="gray" className="mt-3 font-normal text-sm sm:text-md ">
                    {description}
                </Typography>
            </CardBody>
            <CardFooter className="flex items-center justify-center ">
                <Typography as="a" href={date} className="font-normal text-sm sm:text-md">
                    Open Link
                </Typography>
            </CardFooter>
        </Card>
    );
}








export default NotificationGrid;