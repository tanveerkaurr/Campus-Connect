import "react-multi-carousel/lib/styles.css";
import {
    Card,
    CardBody,
    CardFooter,
    Typography,
    Button,
} from "@material-tailwind/react";



export default function Event_card(data) {
    return (
            <div className="w-80 bg-BgBlack mt-2 p-1 rounded-xl   ">
            <Card className="mt-1  gap-0 flex">
                <CardBody>
                    <Typography variant="h5" color="black" className="mb-2 text-sm*2 m-0 p-0 md:m-1 md:p-1 text-ColorTextBlack">
                        {data.obj.eventName}
                    </Typography>
                    <Typography variant="p" className="text-sm text-wrap" >{data.obj.eventDescription}</Typography>
                    <Typography variant="h6" className="text-sm">
                        <span className="text-ColorTextBlack">Event Venue:-</span>
                        {data.obj.eventVenue}
                    </Typography>
                    <Typography variant="h6" className="text-sm">
                        <span className="text-ColorTextBlack">Event Time :- </span>
                        {data.obj.eventTime}
                    </Typography>
                </CardBody>
                <CardFooter className="my-1 p-0 px-2 flex justify-end space-x-4">
                        <span className="text-ColorTextBlack">
                         {data.obj.eventDate}
                        </span>
                    <a href={data.ref_link}>
                        <Button variant="gradient" color="gray" className="text-xs">
                            <a href={data.obj.eventLink}>Participate</a>
                        </Button>
                    </a>
                </CardFooter>
            </Card>
        </div>
    );
}
