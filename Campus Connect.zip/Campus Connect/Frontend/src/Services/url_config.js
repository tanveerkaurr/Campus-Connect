import axios from "axios";

// const baseURL="https://tpc-backend-mb3w.onrender.com"; // dont cange it guys its new link 
const baseURL="http://localhost:5000";

const publicAxios = axios.create({baseURL});

const privateReq = axios.create({baseURL});

privateReq.interceptors.request.use((config)=>{

    const token = localStorage.getItem("token");
    // console.log(token)
    if(token){
        config.headers["Authorization"] = `Bearer ${token}`;
    }
    return config;
});

export {publicAxios,privateReq};