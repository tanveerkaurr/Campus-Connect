import { privateReq } from "../url_config";

export const authController = ()=>{
    return privateReq.post('/api/v1/register/validate');
}