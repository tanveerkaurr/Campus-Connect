import { publicAxios, privateReq } from "../url_config";

const AddApplication = (obj) => {
    return privateReq.post('api/v1/application/create', obj);
}

const FetchApplications = () => {
    return privateReq.get('api/v1/application/getAll');
}

const FetchApplicationPublic = () => {
    return publicAxios.get('api/v1/application/getAll');
}

const DeleteApplication = (id) => {
    // console.log(id);
    return privateReq.delete(`api/v1/application/delete`, { data: { id } });
}

const UpdateApplication = (obj) => {
    return privateReq.put('api/v1/application/update', obj);
}

const ApplyApplication = (obj) => {
    obj.action = "add";
    return privateReq.post('api/v1/application/addorRemoveApplicationAttendee', obj);
}

const RemoveApplication = (obj) => {
    obj.action = "remove";
    return privateReq.post('api/v1/application/addorRemoveApplicationAttendee', obj);
}


export {
    AddApplication,
    FetchApplications,
    DeleteApplication,
    UpdateApplication,
    FetchApplicationPublic,
    ApplyApplication,
    RemoveApplication
};