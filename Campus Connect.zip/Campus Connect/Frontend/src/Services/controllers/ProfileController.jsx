import { publicAxios,privateReq } from "../url_config";

const updateProfile=(obj,headers)=>{
    return privateReq.put('/api/v1/register/update',obj,headers);
}
const fetchProfile=(userId)=>{
    return publicAxios.get('/api/v1/register/getUser?id='+userId);
}

export {updateProfile,fetchProfile};