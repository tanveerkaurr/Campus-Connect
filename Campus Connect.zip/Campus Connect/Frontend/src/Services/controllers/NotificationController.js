import { publicAxios, privateReq } from "../url_config";

const AddNotification = (obj) => {
    return privateReq.post('api/v1/notify/post', obj);
}

const FetchNotifications = () => {
    return privateReq.get('api/v1/notify/getAll');
}

const DeleteNotification = (id) => {
    return privateReq.delete('api/v1/notify/delete', { data: { id } });
}

const UpdateNotification = (obj) => {
    return privateReq.put('api/v1/notify/update', obj);
}

export { AddNotification, FetchNotifications, DeleteNotification,UpdateNotification };
