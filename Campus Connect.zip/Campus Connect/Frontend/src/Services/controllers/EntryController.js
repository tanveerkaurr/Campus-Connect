import { publicAxios } from "../url_config";

const RegisterController=(obj)=>{
    return publicAxios.post('/api/v1/register/signup',obj);
}
const LoginController=(obj)=>{
    return publicAxios.post('/api/v1/register/login',obj);
}

export {RegisterController,LoginController};