import { publicAxios, privateReq } from "../url_config";

const fetch_clubinfo_teacher=(club_id)=>{
    return publicAxios.get('/api/v1/club/getClub?clubId='+club_id);
}

const fetch_AllClubs_teacher=()=>{
    return publicAxios.get('/api/v1/club/getAllClubs');
}

const Add_Club=(obj,headers)=>{
    return privateReq.post('/api/v1/club/createClub',obj,headers)
}

const ClubUpdateController = (obj, headers) => {
    return privateReq.put('/api/v1/club/updateClub' , obj, headers)
}
const UnfollowClub=(obj)=>{
    return privateReq.post('/api/v1/club/removeClubFollower',obj);
}
const FollowClub=(obj)=>{
    return privateReq.post('/api/v1/club/addClubFollower',obj);
}
export {fetch_clubinfo_teacher,fetch_AllClubs_teacher,Add_Club,ClubUpdateController,UnfollowClub,FollowClub};