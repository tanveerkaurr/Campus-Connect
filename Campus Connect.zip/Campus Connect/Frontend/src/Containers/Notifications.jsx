import React, { useEffect } from 'react'
import {
  Card,
  CardHeader,
  Typography,
  CardBody,
  Chip,
  Tabs,
  TabsHeader,
  Tab,
  Input,
} from "@material-tailwind/react";

import { useState } from 'react';
import { authController } from '../Services/controllers/AuthController';
import { FetchNotifications } from '../Services/controllers/NotificationController';
import { FetchApplications } from '../Services/controllers/ApplicationController';
import { ReadMoreApplication } from '../Components';
import { useNavigate } from 'react-router-dom';
import swal from 'sweetalert';


const Notifications = () => {


  // enum:["Club" , "Events" , "Applications"  , "General"],
  const TABS = [
    {
      label: "Inbox",
      value: "Inbox",
    },
    {
      label: "General",
      value: "General",
    },
    {
      label: "Applications",
      value: "Applications",
    },
    {
      label: "Events",
      value: "Events",
    },
    {
      label: "Club",
      value: "Club",
    },
  ];

  const TABLE_HEAD = ["Notification", "Type", "More Info"];

  let emptyFormat =
    [
      {
        label: "Inbox",
        value: "Inbox",
        data: []
      },
      {
        label: "General",
        value: "General",
        data: []
      },
      {
        label: "Applications",
        value: "Applications",
        data: []
      },
      {
        label: "Events",
        value: "Events",
        data: []
      },
      {
        label: "Club",
        value: "Club",
        data: []
      }
    ]

  const [selectedTab, setSelectedTab] = useState("Inbox");
  const [TABLE_ROWS, setTABLE_ROWS] = useState(emptyFormat)
  const [toShow, setToShow] = useState([]);
  const [open, setOpen] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);

  const navigate = useNavigate();

  useEffect(() => {
    validateUser();
    let notficationData = fetchNotifications();
    let applicationData = fetchApplications();
    Promise.all([notficationData, applicationData]).then((values) => {
      let notifications = values[0];
      let applications = values[1];
      let general = notifications.filter((notification) => notification.type === "General");
      let events = notifications.filter((notification) => notification.type === "Events");
      let club = notifications.filter((notification) => notification.type === "Club");
      let applicationsData = applications.map((application) => {
        return {
          type: (application.applicationType == "0" ? "Internship" : application.applicationType == "1" ? "Job" : application.applicationType == "2" ? "Training" : "Workshop"),
          title: application.applicationTitle,
          message: application.companyName,
          link: application.applicationLink,
          fullLengthData: application
        }
      })
      let inbox = general.concat(events).concat(club).concat(applicationsData);
      setTABLE_ROWS([
        {
          label: "Inbox",
          value: "Inbox",
          data: inbox
        },
        {
          label: "General",
          value: "General",
          data: general
        },
        {
          label: "Applications",
          value: "Applications",
          data: applicationsData
        },
        {
          label: "Events",
          value: "Events",
          data: events
        },
        {
          label: "Club",
          value: "Club",
          data: club
        }
      ])
      setToShow(inbox);
    }).catch((err) => {
      console.log(err);
    })
  }, [])

  const validateUser = async () => {

    const token = localStorage.getItem('token');

    if (token === null) {
      navigate('/');
    }

    try {
      const response = await authController();
      // console.log(response);
      if (response.data.success === false) {
        navigate('/');
      }
      // pending usercheck after validate using token
    } catch (err) {
      console.log(err)
      swal("Error", err.response.data.message || err.response.data.error, "error");
    }
  }

  const fetchNotifications = async () => {
    try {
      const response = await FetchNotifications();
      // console.log(response.data.notifications);
      return response.data.notifications;
    }
    catch (err) {
      console.log(err);
    }
  }

  const fetchApplications = async () => {
    try {
      const response = await FetchApplications();
      // console.log(response.data.applications);
      return response.data.applications;
    }
    catch (err) {
      console.log(err);
    }
  }


  return (
    <Card className="m-4 p-2">
      <CardHeader floated={false} shadow={false} className="rounded-none">
        <div className="flex flex-col items-center justify-between gap-4 md:flex-row">
          <Tabs value={selectedTab} className="w-full md:w-max " >
            <TabsHeader className='overflow-x-scroll'>
              {TABS.map(({ label, value }) => (
                <Tab key={value} value={value} onClick={(e) => {
                  setSelectedTab(value)
                  setToShow(TABLE_ROWS.find(row => row.value === value).data)
                }}>
                  &nbsp;&nbsp;{label}&nbsp;&nbsp;
                </Tab>
              ))}
            </TabsHeader>
          </Tabs>

          {/* Search Bar */}

          <div className="w-full md:w-72 m-1 p-1">


            <Input
              label="Search"

              icon={<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
                <path strokeLinecap="round" strokeLinejoin="round" d="m21 21-5.197-5.197m0 0A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607Z" />
              </svg>}
              placeholder="Search"
              onChange={(e) => {
                let search = e.target.value;
                let filteredData = TABLE_ROWS.find(row => row.value === selectedTab).data.filter((data) => {
                  return data.title.toLowerCase().includes(search.toLowerCase()) || data.message.toLowerCase().includes(search.toLowerCase());
                })
                setToShow(filteredData);
              }}
            />
          </div>

        </div>
      </CardHeader>
      <CardBody className="overflow-scroll px-0">

        <table className="mt-4 w-full min-w-max table-auto text-left" >
          <thead>
            <tr>
              {TABLE_HEAD.map((head) => (
                <th
                  key={head}
                  className="border-y border-blue-gray-100 bg-blue-gray-50/50 p-4 "
                >
                  <Typography
                    variant="small"
                    color="blue-gray"
                    className="font-normal leading-none opacity-70"
                  >
                    {head}
                  </Typography>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {toShow.map(({ type, title, message, link }, index) => {
              const isLast = index === TABLE_ROWS.length - 1;
              let classes = isLast
                ? "p-4"
                : "p-4 border-b border-blue-gray-50";

              const colorScheme = type === "Club" ? "blue" : type === "Events" ? "green" : type === "General" ? "yellow" : "red";
              // console.log("index - "+index)
              // console.log(toShow[index])

              const eligibilityBool = (selectedTab === "Applications" || toShow[index].fullLengthData) ? true : false;
              return (
                <tr key={index}>
                  <td className={classes}>
                    {(eligibilityBool && open)
                      ? <ReadMoreApplication open={open} setOpen={setOpen} fullLengthData={toShow[currentIndex].fullLengthData} />
                      : null}
                    <div className="flex flex-col max-w-16 sm:max-w-48 md:max-w-96 lg:max-w-[1400px]">
                      <Typography
                        variant="small"
                        color="blue-gray"
                        className="font-normal"
                      >
                        {title}
                      </Typography>


                      <Typography
                        variant="small"
                        color="blue-gray"
                        className="font-normal opacity-70 "
                      >
                        {message}
                      </Typography>
                    </div>
                  </td>


                  <td className={`${classes} max-w-28`}>
                    <div className="w-max">
                      <Chip
                        variant="ghost"
                        size="sm"
                        value={type}
                        color={colorScheme}
                      />
                    </div>
                  </td>


                  <td className={`${classes} max-w-28`}>
                    {eligibilityBool ?
                      (
                        <Chip
                          variant="ghost"
                          size="sm"
                          value="More Info"
                          onClick={(e) => {
                            setCurrentIndex(index)
                            setOpen(true)
                          }}
                          color="teal"
                          className='w-max hover:border-black hover:text-black'
                        />
                      ) : (
                        <a href={link} target="_blank" rel="noreferrer" >
                          <Chip
                            variant="ghost"
                            size="sm"
                            value="More Info"
                            color="teal"
                            className='w-max hover:border-black hover:text-black'
                          />
                        </a>
                      )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </CardBody>
    </Card>
  );
}

export default Notifications;