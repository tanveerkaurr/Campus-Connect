import React, { useEffect } from 'react'
import { useNavigate } from 'react-router-dom';
import {EventModal} from "../Components"
import {authController} from '../Services/controllers/AuthController';
import swal from 'sweetalert';
const ClubsAdmin=()=>{

  const navigate = useNavigate();
  const validateUser = async () => {

    const token = localStorage.getItem('token');

    if (token === null) {
        navigate('/');
    }

    try{const response = await authController();
      // console.log(response);
      if(response.data.success===false){
        navigate('/');
    }
      // pending usercheck after validate using token
      }catch(err){
        console.log(err)
        swal("Error",err.response.data.message||err.response.data.error, "error");
      }
}
  useEffect(()=>{
    validateUser();
  },[])

  return (

    <div className='flex justify-center align-middle'>

<EventModal/>

    </div>
  )
}

export default ClubsAdmin;


