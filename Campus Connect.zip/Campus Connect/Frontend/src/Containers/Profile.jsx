import React from 'react'
import { useState, useEffect } from 'react';
import { ChipIcon, ListCard, TimeLineCard } from '../Components';
import {
  MDBCol,
  MDBContainer,
  MDBRow,
  MDBCard,
  MDBCardText,
  MDBCardBody,
  MDBCardImage,
  MDBListGroup,
} from 'mdb-react-ui-kit';
import { Input } from "@material-tailwind/react";
import { Button, Radio } from "@material-tailwind/react";
import swal from 'sweetalert';
import {updateProfile,fetchProfile} from "../Services/controllers/ProfileController";
import {authController} from '../Services/controllers/AuthController';
import { useNavigate } from 'react-router-dom';



const Profile = () => {
  
  const navigate = useNavigate();
  const token=localStorage.getItem("token");

  const [profile, setProfile] = useState({
    userId:localStorage.getItem("userId"),
    name: localStorage.getItem("name"),
    batch: '2021',
    branch: 'BTech in Computer Science and Engineering',
    rollNumber: '123456',
    contact: '1234567890',
    gender: "Male",
    dateOfBirth: "2024-05-05",
    email:localStorage.getItem("email"),
    address: "Some where in the world",
    cvLink: "https://www.google.com",
    // role: 'Student',
    clubMembership: [
      {
        clubId: 1,
        clubName: 'Coding Club',
      },
      {
        clubId: 2,
        clubName: 'Dance Club',
      },
      {
        clubId: 3,
        clubName: 'Music Club',
      },
      {
        clubId: 4,
        clubName: 'Drama Club',
      }
    ],
    clubFollowing: [{
      clubId: 1,
      clubName: 'Coding Club'
    }],
    applications: [
      {
        id: 1,
        name: "Application 1 skjdfvnbsdf jsb skdfghdfg ",
        dateApplied: "12/12/2021",
      },
      {
        id: 2,
        name: "Application 2 skjdfvnbsdf jsb skdfghdfg ",
        dateApplied: "12/12/2021",
      },
      {
        id: 3,
        name: "Application 3 skjdfvnbsdf jsb skdfghdfg ",
        dateApplied: "12/12/2021",
      }
    ],
    profileImage: ""
  });

  const [applications, setApplications] = useState(profile.applications);
  const [clubs, setClubs] = useState([]);
  const [enableEdit, setEnableEdit] = useState(false);
  const [previewImage, setPreviewImage] = useState(
    {
      profileImage: "",
      name: ""
    }
  );

  const fetchprofile=async()=>{
    try{
      const serverMsg = await fetchProfile(profile.userId);
      // console.log(serverMsg.data.user.applications);

      setProfile({
        ...profile,
        name : serverMsg.data.user.name,
        batch: serverMsg.data.user.personalInfo.batch,
        branch: serverMsg.data.user.personalInfo.branch,
        rollNumber: serverMsg.data.user.personalInfo.rollNumber,
        contact: serverMsg.data.user.personalInfo.contact,
        gender: serverMsg.data.user.personalInfo.gender,
        dateOfBirth: serverMsg.data.user.personalInfo.dateOfBirth,
        email: serverMsg.data.user.email,
        role:(serverMsg.data.user.role=="1"?"Student":"Admin"),
        address: serverMsg.data.user.personalInfo.address,
        cvLink: serverMsg.data.user.personalInfo.cvLink,
        profileImage:serverMsg.data.user.personalInfo.image
      })

      setApplications(serverMsg.data.user.applications);
      setClubs(serverMsg.data.user.clubMembership); 
      setPreviewImage({
        profileImage:serverMsg?.data?.user?.personalInfo?.image
      })
    }catch(err){
      console.log(err)
      swal("Error",err.response.data.message||err.response.data.error, "error");
    }
  }

  const validateUser = async () => {
    const token = localStorage.getItem('token');
    // console.log(token);
    if (token === null) {
        navigate('/');
    }

    try{const response = await authController();
      // console.log(response);
      if(response.data.success===false){
        navigate('/');
      }
      // pending usercheck after validate using token
      }catch(err){
        console.log(err)
        swal("Error",err.response.data.message||err.response.data.error, "error");
      }
   }

  useEffect(() => {
    const profileCopy = localStorage.getItem('profile');
    if (profileCopy) {
      setProfile(JSON.parse(profileCopy));
    }
    fetchprofile();
    validateUser();
  }, []);

  

  // let enableEdit = true;

  const ButtonGroup = () => {
    

    const saveprofile=async()=>{
      var formdata = new FormData();
      for (var prop in profile) {
      formdata.append(prop, profile[prop]);
    }
    // console.log(profile);
    // console.log(formdata);
    try{
      const serverMsg = await updateProfile(formdata, {
        headers: { "Content-Type": "multipart/form-data" },
      });
        // console.log(serverMsg);
        if(serverMsg.data.success===true){
          swal("Changes Saved!", "Your changes have been saved successfully!", "success");
        }
        else{
          swal("Error!", "Something went wrong!", "Error");
        }
    }catch(err){
      console.log(err)
      swal("Error",err.response.data.message||err.response.data.error, "error");
    }
    }
    return (
      <div className="flex w-max gap-4 m-4">
        <Button ripple={true}
          color={enableEdit ? "red" : "blue"}
          onClick={() => {
            setEnableEdit(!enableEdit);
          }}>
          {enableEdit ? "Cancel Changes" : "Enable Editing"}
        </Button>
        {enableEdit && (
          <Button ripple={true}
            color="green"
            onClick={() => {
              // save in local storage
              // localStorage.setItem('profile', JSON.stringify(profile));
              // localStorage.removeItem("profile")
              // confirm changes
              saveprofile();
              fetchprofile();
              // swal("Changes Saved!", "Your changes have been saved successfully!", "success");
              setEnableEdit(!enableEdit);
            }}>Save Changes
          </Button>
        )}
      </div>
    )
  }


  
  return (
    <MDBContainer className="py-5 w-full h-full ">
      <MDBRow>
        {enableEdit ? (
          <MDBCol >
            <MDBCard className="mb-4 flex align-middle justify-center ">
              <MDBCardBody className="flex align-middle justify-center flex-col gap-y-4">
                <div className='flex justify-center align-middle'>
                  <div class="flex items-center justify-center w-full gap-x-10">

                    <label for="dropzone-file" class="flex flex-col items-center justify-center w-full h-64 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 dark:hover:bg-bray-800 dark:bg-gray-700 hover:bg-gray-100 dark:border-gray-600 dark:hover:border-gray-500 dark:hover:bg-gray-600">
                      <div class="flex flex-col items-center justify-center pt-5 pb-6">
                        <svg class="w-8 h-8 mb-4 text-gray-500 dark:text-gray-400" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 16">
                          <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 13h3a3 3 0 0 0 0-6h-.025A5.56 5.56 0 0 0 16 6.5 5.5 5.5 0 0 0 5.207 5.021C5.137 5.017 5.071 5 5 5a4 4 0 0 0 0 8h2.167M10 15V6m0 0L8 8m2-2 2 2" />
                        </svg>
                        <p class="mb-2 text-sm text-gray-500 dark:text-gray-400"><span class="font-semibold">Click to upload</span> or drag and drop</p>
                        <p class="text-xs text-gray-500 dark:text-gray-400">PNG, JPG, JPEG</p>
                      </div>
                      <input id="dropzone-file" type="file" class="hidden" accept="image/png, image/jpeg, image/jpg" onChange={(e) => {

                        setPreviewImage({
                          profileImage: URL.createObjectURL(e.target.files[0]),
                          name: e.target.files[0].name
                        });
                        setProfile({ ...profile, profileImage:e.target.files[0] })
                        // console.log((e.target.files[0]))
                      }}
                      />
                    </label>
                    {previewImage &&
                      <div className="w-48 h-48 object-cover rounded-full" >
                        <img src={previewImage.profileImage} alt="Upload to preview" />
                        {previewImage.name}
                      </div>
                    }
                  </div>
                </div>
                <Input label="User Name" value={profile.name} onChange={(e) => setProfile({ ...profile, name: e.target.value })} />
                <Input label="Batch" value={profile.batch} onChange={(e) => setProfile({ ...profile, batch: e.target.value })} />
                <Input label="Branch" value={profile.branch} onChange={(e) => setProfile({ ...profile, branch: e.target.value })} />
                <ChipIcon text={profile.role} alignment="flex justify-center align-middle animate-pulse" />
              </MDBCardBody>

            </MDBCard>
            <MDBCard className="mb-4 mb-lg-0">
              <MDBCard className="mb-4 ">
                <MDBCardBody className=''>
                  <MDBRow className='m-2'>
                    <MDBCol>
                      <MDBCardText>Email</MDBCardText>
                    </MDBCol>
                    <MDBCol >
                      <Input label="Email" value={profile.email} onChange={(e) => setProfile({ ...profile, email: e.target.value })} 
                      disabled={true} 
                      />
                    </MDBCol>
                  </MDBRow>
                  <hr />
                  <MDBRow className='m-2'>
                    <MDBCol >
                      <MDBCardText>Mobile Number</MDBCardText>
                    </MDBCol>
                    <MDBCol >
                      <Input label="Mobile Number" value={profile.contact} onChange={(e) => setProfile({ ...profile, contact: e.target.value })} />
                    </MDBCol>
                  </MDBRow>
                  <hr />
                  <MDBRow className='m-2'>
                    <MDBCol >
                      <MDBCardText>Roll Number</MDBCardText>
                    </MDBCol>
                    <MDBCol >
                      <Input label="Roll Number" value={profile.rollNumber} onChange={(e) => setProfile({ ...profile, rollNumber: e.target.value })} />
                    </MDBCol>
                  </MDBRow>
                  <hr />
                  <MDBRow className='m-2'>
                    <MDBCol>
                      <MDBCardText>Gender</MDBCardText>
                    </MDBCol>
                    <MDBCol className='flex justify-center align-middle gap-x-5'>
                      <div className='flex gap-1'>
                        <input type='radio' name="gender" id="male" value="Male"
                          checked={profile.gender === "Male"}
                          onChange={(e) => {
                            setProfile({ ...profile, gender: e.target.value });
                          }} />
                        <label htmlFor="male">Male</label>
                      </div>

                      <div className='flex gap-1'>
                        <input type='radio' name="gender" id="female" value="Female"
                          checked={profile.gender === "Female"}
                          onChange={(e) => {
                            setProfile({ ...profile, gender: e.target.value });
                          }} />
                        <label htmlFor="female">Female</label>
                      </div>

                      <div className='flex gap-1'>
                        <input type='radio' name="gender" id="others" value="Others"
                          checked={profile.gender === "Others"}
                          onChange={(e) => {
                            setProfile({ ...profile, gender: e.target.value });
                          }} />
                        <label htmlFor="others">Others</label>
                      </div>

                    </MDBCol>
                  </MDBRow>
                  <hr />
                  <MDBRow className='m-2'>
                    <MDBCol >
                      <MDBCardText>Date Of Birth</MDBCardText>
                    </MDBCol>
                    <MDBCol >
                      <Input label="Date Of Birth" type='date' value={profile.dateOfBirth} onChange={(e) => setProfile({ ...profile, dateOfBirth: e.target.value })} />
                    </MDBCol>
                  </MDBRow>
                  <hr />
                  <MDBRow className='m-2'>
                    <MDBCol >
                      <MDBCardText>Address</MDBCardText>
                    </MDBCol>
                    <MDBCol >
                      <Input label="Address" value={profile.address} onChange={(e) => setProfile({ ...profile, address: e.target.value })} />
                    </MDBCol>
                  </MDBRow>
                  <hr />
                  <MDBRow className='m-2'>
                    <MDBCol >
                      <MDBCardText>Resume Link</MDBCardText>
                    </MDBCol>
                    <MDBCol >
                      <Input label="Resume Link" value={profile.cvLink} onChange={(e) => setProfile({ ...profile, cvLink: e.target.value })} />
                    </MDBCol>
                  </MDBRow>
                </MDBCardBody>
              </MDBCard>
            </MDBCard>
            <ButtonGroup />
          </MDBCol>
        ) :
          (
            <MDBCol >
              <MDBCard className="mb-4 flex align-middle justify-center ">
                <MDBCardBody className="flex align-middle justify-center flex-col gap-y-4">
                  <div className='flex justify-center align-middle'>
                    <MDBCardImage
                      src={profile.profileImage}
                      alt="avatar"
                      className="rounded-circle"
                      style={{ width: '150px' }}
                      fluid />
                  </div>
                  <p className="text-center">
                    {profile.name}
                  </p>
                  <p className="text-center">{profile.batch}</p>
                  <p className="text-center">{profile.branch}</p>
                  <ChipIcon text={profile.role} alignment="flex justify-center align-middle animate-pulse" />
                </MDBCardBody>
              </MDBCard>
              <MDBCard className="mb-4 mb-lg-0">
                <MDBCard className="mb-4 ">
                  <MDBCardBody className=''>
                    <MDBRow className='m-2'>
                      <MDBCol>
                        <MDBCardText>Email</MDBCardText>
                      </MDBCol>
                      <MDBCol >
                        <MDBCardText className="text-muted">{profile.email}</MDBCardText>
                      </MDBCol>
                    </MDBRow>
                    <hr />
                    <MDBRow className='m-2'>
                      <MDBCol >
                        <MDBCardText>Mobile Number</MDBCardText>
                      </MDBCol>
                      <MDBCol >
                        <MDBCardText className="text-muted">{profile.contact}</MDBCardText>
                      </MDBCol>
                    </MDBRow>
                    <hr />
                    <MDBRow className='m-2'>
                      <MDBCol >
                        <MDBCardText>Roll Number</MDBCardText>
                      </MDBCol>
                      <MDBCol >
                        <MDBCardText className="text-muted">{profile.rollNumber}</MDBCardText>
                      </MDBCol>
                    </MDBRow>
                    <hr />
                    <MDBRow className='m-2'>
                      <MDBCol >
                        <MDBCardText>Gender</MDBCardText>
                      </MDBCol>
                      <MDBCol >
                        <MDBCardText className="text-muted">{profile.gender}</MDBCardText>
                      </MDBCol>
                    </MDBRow>
                    <hr />
                    <MDBRow className='m-2'>
                      <MDBCol >
                        <MDBCardText>Date Of Birth</MDBCardText>
                      </MDBCol>
                      <MDBCol >
                        <MDBCardText className="text-muted">{profile.dateOfBirth}</MDBCardText>
                      </MDBCol>
                    </MDBRow>
                    <hr />
                    <MDBRow className='m-2'>
                      <MDBCol >
                        <MDBCardText>Address</MDBCardText>
                      </MDBCol>
                      <MDBCol >
                        <MDBCardText className="text-muted">{profile.address}</MDBCardText>
                      </MDBCol>
                    </MDBRow>
                    <hr />
                    <MDBRow className='m-2'>
                      <MDBCol >
                        <MDBCardText>Resume Link</MDBCardText>
                      </MDBCol>
                      <MDBCol >
                        <MDBCardText className="">
                          <a href={profile.cvLink} target="_blank" rel="noreferrer" className='text-ellipsis'>{profile.cvLink}</a>
                        </MDBCardText>
                      </MDBCol>
                    </MDBRow>
                  </MDBCardBody>
                </MDBCard>
              </MDBCard>
              <ButtonGroup />
            </MDBCol>

          )}


        <MDBCol >

          <MDBRow className='flex justify-center align-middle flex-col'>
            <MDBCol>
              <MDBCard className="mb-4">
                <MDBCardBody>
                  <MDBCardText className="mb-4"><span className="text-primary font-italic me-1">Applications</span></MDBCardText>
                  <ListCard data={applications} next={fetchprofile} />
                </MDBCardBody>
              </MDBCard>
            </MDBCol>

            <MDBCol >
              <MDBCard className="mb-4 mb-md-0">
                <MDBCardBody>
                  <MDBCardText className="mb-4"><span className="text-primary font-italic me-1">Student Clubs</span></MDBCardText>
                  <MDBListGroup>
                    <TimeLineCard data={clubs} />
                  </MDBListGroup>
                </MDBCardBody>
              </MDBCard>
            </MDBCol>
          </MDBRow>
        </MDBCol>

      </MDBRow>
    </MDBContainer>
  );
}

export default Profile;





