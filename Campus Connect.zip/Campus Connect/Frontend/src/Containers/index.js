export { default as Dashstudent} from './Dash-student.jsx';
export { default as ClubsAdmin} from './ClubsAdmin.jsx';
export { default as Profile} from './Profile.jsx';
export { default as Notifications} from './Notifications.jsx';
export { default as Clubs} from './Clubs-student.jsx';
export { default as Login} from './Register.jsx';
export { default as Error404} from './Error404.jsx';
export { default as ManageNotifications} from './ManageNotifications.jsx';