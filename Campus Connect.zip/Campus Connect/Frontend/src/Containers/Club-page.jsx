import { Typography } from '@material-tailwind/react';
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom';
import Event_card from '../Components/Event-card';
import {authController} from '../Services/controllers/AuthController';
import swal from 'sweetalert';
import {fetch_clubinfo_teacher} from "../Services/controllers/ClubController"
// const clubsData = [
//     {
//       clubId: 1,
//       clubName: "Chess Club",
//       clubDescription: "A club for chess enthusiasts to practice and compete.",
//       clubType: "Hobby",
//       clubContact: "Teacher",
//       clubEvents: ["Chess Tournament"],
//       clubMembers: [123, 456, 789],
//       clubFollowers: [789, 567],
//       clubImage: "https://www.mrsptu.ac.in/images/mrslogo.png"
//     },
//     {
//       clubId: 2,
//       clubName: "Science Club",
//       clubDescription: "Explore and conduct experiments in various sciences.",
//       clubType: "Academic",
//       clubContact: "Student",
//       clubEvents: ["Chemistry Lab", "Guest Lecture"],
//       clubMembers: [234, 567, 890],
//       clubFollowers: [123, 456],
//       clubImage: "https://www.mrsptu.ac.in/images/mrslogo.png"
//     },
//     {
//       clubId: 3,
//       clubName: "Photography Club",
//       clubDescription: "Learn and practice photography techniques.",
//       clubType: "Hobby",
//       clubContact: "Student",
//       clubEvents: ["Photo Walk", "Workshop"],
//       clubMembers: [123, 678, 901],
//       clubFollowers: [234, 789],
//       clubImage: "https://www.mrsptu.ac.in/images/mrslogo.png"
//     },
//     {
//       clubId: 4,
//       clubName: "Debate Society",
//       clubDescription: "Engage in debates and improve public speaking skills.",
//       clubType: "Academic",
//       clubContact: "Teacher",
//       clubEvents: ["Inter-school Debate"],
//       clubMembers: [456, 789, 312],
//       clubFollowers: [345, 901],
//       clubImage: "https://www.mrsptu.ac.in/images/mrslogo.png"
//     },
//     {
//       clubId: 5,
//       clubName: "Eco Club",
//       clubDescription: "Promote environmental awareness and sustainability.",
//       clubType: "Social Cause",
//       clubContact: "Student",
//       clubEvents: ["Tree Plantation Drive"],
//       clubMembers: [567, 890, 123],
//       clubFollowers: [456, 312],
//       clubImage: "https://www.mrsptu.ac.in/images/mrslogo.png"
//     }
// ];

// const eventData = [
//     {
//         clubId: "1",
//         eventName: "Chess Tournament",
//         eventDescription: "Annual chess tournament for chess enthusiasts.",
//         eventDate: "2024-06-15",
//         eventTime: "09:00 AM",
//         eventVenue: "Chess Club Room",
//         eventHeadContact: 1234567890,
//         eventLink: "https://example.com/chess-tournament"
//     },
//     {
//         clubId: "2",
//         eventName: "Chemistry Lab",
//         eventDescription: "Hands-on experience with chemistry experiments.",
//         eventDate:"2024-07-20",
//         eventTime: "10:00 AM",
//         eventVenue: "Science Lab",
//         eventHeadContact: 2345678901,
//         eventLink: "https://example.com/chemistry-lab"
//     },
//     {
//         clubId: "3",
//         eventName: "Photo Walk",
//         eventDescription: "Explore the campus while capturing moments.",
//         eventDate:"2024-08-05",
//         eventTime: "04:00 PM",
//         eventVenue: "Campus Grounds",
//         eventHeadContact: 3456789012,
//         eventLink: "https://example.com/photo-walk"
//     },
//     {
//         clubId: "4",
//         eventName: "Inter-school Debate",
//         eventDescription: "Engage in debates with students from other schools.",
//         eventDate:"2024-09-10",
//         eventTime: "02:00 PM",
//         eventVenue: "Auditorium",
//         eventHeadContact: 4567890123,
//         eventLink: "https://example.com/inter-school-debate"
//     },
//     {
//         clubId: "5",
//         eventName: "Tree Plantation Drive",
//         eventDescription: "Contribute to environmental sustainability by planting trees.",
//         eventDate:"2024-10-15",
//         eventTime: "08:00 AM",
//         eventVenue: "Campus Entrance",
//         eventHeadContact: 5678901234,
//         eventLink: "https://example.com/tree-plantation-drive"
//     },
//     {
//         clubId: "1",
//         eventName: "Chess Workshop",
//         eventDescription: "Learn advanced chess strategies.",
//         eventDate:"2024-06-22",
//         eventTime: "11:00 AM",
//         eventVenue: "Chess Club Room",
//         eventHeadContact: 1234567890,
//         eventLink: "https://example.com/chess-workshop"
//     },
//     // Add more events with replicated clubIds if needed
// ];

function Clubpage() {
    const navigate = useNavigate();
    const club_Id=localStorage.getItem("ClubId");
    const [clubinfo,setclubinfo]=useState([])
    const [clubevent,setclubevent]=useState([])

    const fetch_clubinfo=async()=>{
      try{
        const response = await fetch_clubinfo_teacher(club_Id);
        setclubevent(response.data.data.clubEventsList)
        setclubinfo(response.data.data);
        // console.log(response.data.data);
      }catch(err){
       console.log(err)
       swal("Error",err.response.data.message||err.response.data.error, "error");
      }
      }
    // const specificclub = clubsData.filter((obj)=>{
    //     return(localStorage==obj.clubId);
    // })
    // const events = eventData.filter((obj)=>{
    //     return(localStorage==obj.clubId);
    // })
    
    const validateUser = async () => {

      const token = localStorage.getItem('token');

      if (token === null) {
          navigate('/');
      }

      try{const response = await authController();
        // console.log(response);
        if(response.data.success===false){
          navigate('/');
      }
        // pending usercheck after validate using token
        }catch(err){
          console.log(err)
          swal("Error",err.response.data.message||err.response.data.error, "error");
        }
  }
    useEffect(()=>{
      validateUser();
      fetch_clubinfo()
    },[])

  return (
    <div>
        <div className='mb-2 flex justify-between'>
        <div className='flex mt-6 ms-6'>
          <img src={clubinfo.clubImage} className="w-12" alt={clubinfo.clubName}></img>
          <Typography variant='h5' className='mx-4 mt-3'>{clubinfo.clubName}</Typography>
        </div>
        <div className='flex mt-6 me-4'>
          <Typography variant='paragraph' className='mx-4 mt-3'>{clubinfo.clubHeadName}:-{clubinfo.clubHeadContact}</Typography>
        </div>
         </div>
        <hr></hr>
        <div className='flex ms-4'>
          <Typography variant='paragraph' className='mx-4 mt-3'>{clubinfo.clubDescription}</Typography>
        </div>
        {/* events Heading */}
        <div>
            <p className='font-sans text-4xl m-7 flex justify-center'>Events</p>
        </div>
        {/* Start Cards */}
        
        <div className='flex justify-center align-middle mx-4 my-2 py-4 gap-4 flex-wrap'>
        {
            clubevent.map((obj)=>{
                return(
                    <Event_card obj={obj}></Event_card>
                )
            })
        } 
          </div>   
        
    </div>
  )
}

export default Clubpage