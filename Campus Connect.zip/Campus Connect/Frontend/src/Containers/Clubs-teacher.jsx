import { Typography } from '@material-tailwind/react';
import { CreateClubModal } from '../Components';
import Club_card from '../Components/Club-card';
import {useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {authController} from '../Services/controllers/AuthController';
import swal from 'sweetalert';
import { fetch_AllClubs_teacher } from '../Services/controllers/ClubController';


// const clubsData = [
//   {
//     clubName: "Chess Club",
//     clubDescription: "A club for chess enthusiasts to practice and compete.",
//     clubType: "Hobby",
//     clubContact: "Teacher", // Assuming "Teacher" or "Student" for simplicity
//     clubEvents: ["Chess Tournament"],
//     clubMembers: [123, 456, 789],
//     clubFollowers: [789, 567],
//     clubImage: "https://www.mrsptu.ac.in/images/mrslogo.png"
//   },
//   {
//     clubName: "Science Club",
//     clubDescription: "Explore and conduct experiments in various sciences.",
//     clubType: "Academic",
//     clubContact: "Student", // Assuming "Teacher" or "Student" for simplicity
//     clubEvents: ["Chemistry Lab", "Guest Lecture"],
//     clubMembers: [234, 567, 890],
//     clubFollowers: [123, 456],
//     clubImage: "https://www.mrsptu.ac.in/images/mrslogo.png"
//   },
//   {
//     clubName: "Photography Club",
//     clubDescription: "Learn and practice photography techniques.",
//     clubType: "Hobby",
//     clubContact: "Student", // Assuming "Teacher" or "Student" for simplicity
//     clubEvents: ["Photo Walk", "Workshop"],
//     clubMembers: [123, 678, 901],
//     clubFollowers: [234, 789],
//     clubImage: "https://www.mrsptu.ac.in/images/mrslogo.png"
//   },
//   {
//     clubName: "Debate Society",
//     clubDescription: "Engage in debates and improve public speaking skills.",
//     clubType: "Academic",
//     clubContact: "Teacher", // Assuming "Teacher" or "Student" for simplicity
//     clubEvents: ["Inter-school Debate"],
//     clubMembers: [456, 789, 312],
//     clubFollowers: [345, 901],
//     clubImage: "https://www.mrsptu.ac.in/images/mrslogo.png"
//   },
//   {
//     clubName: "Eco Club",
//     clubDescription: "Promote environmental awareness and sustainability.",
//     clubType: "Social Cause",
//     clubContact: "Student", // Assuming "Teacher" or "Student" for simplicity
//     clubEvents: ["Tree Plantation Drive"],
//     clubMembers: [567, 890, 123],
//     clubFollowers: [456, 312],
//     clubImage: "https://www.mrsptu.ac.in/images/mrslogo.png"
//   }
// ];


function Teacher_Clubs({role}) {
  const navigate=useNavigate();
  const [clubsData,setclubsData]=useState([]);
  useEffect(()=>{
    fetch_AllClubs();
    // validateUser();
  },[])

  async function fetch_AllClubs(){
      try{
        const response = await fetch_AllClubs_teacher();
        setclubsData(response.data.data);
        // console.log(clubsData);
      }catch(err){
        console.log(err)
        swal("Error",err.response.data.message||err.response.data.error, "error");
      }
  }

  // handleOpen={handleOpen} open={open} setOpen={setOpen}  
  const [open, setOpen] = useState(false);
  const handleOpen = () => setOpen((cur) => !cur);


  if(open){
    return <CreateClubModal handleOpen={handleOpen} open={open} setOpen={setOpen} />
  }

  return (
    <div>
      <div className='flex justify-between m-4 p-2'>
        <Typography variant='h4' > Configurable Clubs </Typography>
        <button
          className="align-middle font-sans font-bold text-center uppercase transition-all disabled:opacity-50 disabled:shadow-none disabled:pointer-events-none text-xs py-3 px-6 rounded-lg bg-gray-900 text-white shadow-md shadow-gray-900/10 hover:shadow-lg hover:shadow-gray-900/20 focus:opacity-[0.85] focus:shadow-none active:opacity-[0.85] active:shadow-none flex justify-end "
          type="button"
          onClick={() => {
            handleOpen();
          }}
        > Add Club</button>
      </div>
      {
        clubsData.map((obj) => {
          return (<Club_card key={obj.clubName} obj={obj} follower={true} buttonVisible={false} role={role}></Club_card>)
        })
      }

    </div>
  )
}

export default Teacher_Clubs;