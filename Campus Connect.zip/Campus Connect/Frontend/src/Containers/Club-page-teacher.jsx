import React, { useEffect, useState } from 'react'
import { fetch_clubinfo_teacher } from '../Services/controllers/ClubController'
import { Typography } from '@material-tailwind/react';
import Event_card from '../Components/Event-card';
import swal from 'sweetalert';
import {authController} from '../Services/controllers/AuthController';
import { CreateClubModal } from '../Components';
import { useNavigate } from 'react-router-dom';

const ccip = "https://www.mrsptu.ac.in/images/mrslogo.png"
// const clubmembers = [
//     {
//         name: "John Doe",
//         image: "john.jpg",
//         branch: "Computer Science",
//         batch: "2023",
//         number: "+1234567890",
//         email: "john.doe@example.com"
//     },
//     {
//         name: "Jane Smith",
//         image: "jane.jpg",
//         branch: "Electrical Engineering",
//         batch: "2024",
//         number: "+1987654321",
//         email: "jane.smith@example.com"
//     }
//     ,
//     {
//         name: "Alice Johnson",
//         image: "alice.jpg",
//         branch: "Mechanical Engineering",
//         batch: "2022",
//         number: "+1122334455",
//         email: "alice.johnson@example.com"
//     },
//     {
//         name: "Bob Williams",
//         image: "bob.jpg",
//         branch: "Civil Engineering",
//         batch: "2023",
//         number: "+1555666777",
//         email: "bob.williams@example.com"
//     },
//     {
//         name: "Eva Brown",
//         image: "eva.jpg",
//         branch: "Chemical Engineering",
//         batch: "2024",
//         number: "+1777888999",
//         email: "eva.brown@example.com"
//     },
//     {
//         name: "Michael Taylor",
//         image: "michael.jpg",
//         branch: "Aerospace Engineering",
//         batch: "2023",
//         number: "+1444555666",
//         email: "michael.taylor@example.com"
//     }
// ];

function Clubpage_teacher() {
    const navigate = useNavigate();
    const[clubdata,setclubdata]=useState({})
    const[clubevents,setclubevents]=useState()
    const[clubmembers,setclubmembers]=useState([])
    const [open, setOpen] = useState(false);
    const handleOpen = () => setOpen(!open);

    var club_Id=localStorage.getItem("ClubId")
//====================== TRY CATCH PENDING =====================================
    const fetch_clubdata=async()=>{
        const serverMsg= await fetch_clubinfo_teacher(club_Id);
        setclubmembers(serverMsg.data.data.clubMembers);
        if(serverMsg.data.success===false){
            swal("Not found!","Club Not found","error")
            
            return;
        }
        setclubdata(serverMsg.data.data);
        setclubevents(serverMsg.data.data.clubEventsList);
        // setclubmembers(serverMsg.data.data.clubFollowers);
        
        }
        const validateUser = async () => {

            const token = localStorage.getItem('token');
    
            if (token === null) {
                navigate('/');
            }
    
            try{const response = await authController();
            // console.log(response);
            if(response.data.success===false){
                navigate('/');
            }
            // pending usercheck after validate using token
            }catch(err){
                console.log(err)
                swal("Error",err.response.data.message||err.response.data.error, "error");
            }
        }
    

    useEffect(()=>{
        fetch_clubdata();
        validateUser();
    },[])


    if(open){
        return(
            <CreateClubModal handleOpen={handleOpen} open={open} setOpen={setOpen} EditInfo = {clubdata} toEdit={true} CTA={fetch_clubdata}/>
        )
    }

    

  return (
    <div>
        <div className='mb-2 flex justify-between'>
        <div className='flex mt-6 ms-6'>
          <img src={clubdata.clubImage} className="w-12" alt={clubdata.clubName}></img>
          <Typography variant='h5' className='mx-4 mt-3'>{clubdata.clubName}</Typography>
        </div>
        <div className='flex mt-6 me-4'>
            <button
              className="align-middle font-sans font-bold text-center uppercase transition-all disabled:opacity-50 disabled:shadow-none disabled:pointer-events-none text-xs py-3 px-6 rounded-lg bg-gray-900 text-white shadow-md shadow-gray-900/10 hover:shadow-lg hover:shadow-gray-900/20 focus:opacity-[0.85] focus:shadow-none active:opacity-[0.85] active:shadow-none"
              type="button"
              onClick={()=>{
                handleOpen()
              }}
              > Edit Club Info</button>
        </div>
         </div>
         <hr />
         <div className='flex ms-4'>
          <Typography variant='paragraph' className='mx-4 mt-3'>{clubdata.clubDescription}</Typography>
        </div>
        {/* events Heading */}
        <div className='py-3 my-6' >
        <Typography variant='h3' className="flex items-center gap-1 my-6 ms-6  text-xl justify-center">Events</Typography>
        <div className='flex align-middle mx-24 my-2 py-4 gap-4 flex-wrap'>
            {clubevents ? clubevents.map((obj)=>{
                return(
                    <Event_card obj={obj} ></Event_card>
                )
            }) : <h1>No such event Now</h1>
            } 
          </div> 
      </div>
      {/* List of Club members  */}
      <Typography variant='h3' className="flex items-center gap-1 my-6 ms-6  text-xl justify-center">Club Members</Typography>
      <div className='flex mx-24 my-2 py-4 gap-4 flex-wrap'>
            {clubmembers ? clubmembers.map((obj)=>{
                    return(
                    <div className='w-[47%] border-8 border-gray-800 mt-4 '>
                            <div className='flex'>
                            <img className='w-16  ms-4 mt-4' src={ccip} alt={obj.name} />
                            <p className='text-xl mt-3 m-auto'>{obj.name}</p>
                            </div>
                            <div className='ms-8 mt-4 '>Email:- {obj.email}</div>
                            <div className='ms-8 mt-2'>Contact:- {obj.number}</div>
                            <div className='flex justify-between'>
                            <span className='ms-8 mt-2'>Branch:- {obj.branch}</span>
{/* =====================Button of remove member is canceled==================================== */}
                            {/* <button
                            className="align-middle me-5 font-sans font-bold text-center uppercase transition-all disabled:opacity-50 disabled:shadow-none disabled:pointer-events-none text-xs py-2 px-6 rounded-lg bg-red-900 text-white shadow-md shadow-red-900/50 hover:shadow-lg hover:shadow-gray-900/20 focus:opacity-[0.85] focus:shadow-none active:opacity-[0.85] active:shadow-none"
                                type="button"> remove</button> */}
                            </div>
                            <div className='ms-8 my-2'>Batch:- {obj.batch}</div>
                    </div>
                    )
                }): <h1>No Member</h1>
            }

      </div>


    </div>
  )
}

export default Clubpage_teacher