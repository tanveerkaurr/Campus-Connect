import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Club_card from '../Components/Club-card';
import { authController } from '../Services/controllers/AuthController';
import swal from 'sweetalert';
import { fetch_AllClubs_teacher } from "../Services/controllers/ClubController";
import { fetchProfile } from "../Services/controllers/ProfileController";

function Clubs({ role }) {
  const [clubsData, setClubsData] = useState([]);
  const [userClubs, setUserClubs] = useState([]);
  const [notUserClubs, setNotUserClubs] = useState([]);

  const userId = localStorage.getItem("userId");
  const navigate = useNavigate();

  const validateUser = async () => {
    const token = localStorage.getItem('token');

    if (token === null) {
      navigate('/');
    }

      try{const response = await authController();
        // console.log(response);
        if(response.data.success===false){
          navigate('/');
      }
    } catch (err) {
      console.log(err);
      swal("Error", err.response.data.message || err.response.data.error, "error");
    }
  };

  const fetchAllClubs = async () => {
    try {
      const response = await fetch_AllClubs_teacher();
      setClubsData(response.data.data);
    } catch (err) {
      console.log(err);
      swal("Error", err.response.data.message || err.response.data.error, "error");
    }
  };

  const fetchUserClubs = async () => {
    try {
      const response = await fetchProfile(userId);
      setUserClubs(response.data.user.clubFollowing);
    } catch (err) {
      console.log(err);
      swal("Error", err.response.data.message || err.response.data.error, "error");
    }
  };

  useEffect(() => {
    const initializeData = async () => {
      await validateUser();
      await fetchAllClubs();
      await fetchUserClubs();
    };

    initializeData();
  }, []);

  const filterClubs = () => {
    if(clubsData.length == 0){
      // alert("NO club");
      return;
    }
    else if(userClubs.length == 0){
      // alert("Not following");
      setNotUserClubs(clubsData);
      return;
    }
    const userClubIds = new Set(userClubs.map(club => club._id));
    const userClubsData = clubsData.filter(club => userClubIds.has(club._id));
    const notUserClubsData = clubsData.filter(club => !userClubIds.has(club._id));
  
    setUserClubs(userClubsData);
    setNotUserClubs(notUserClubsData);
  };
  useEffect(() => {

    if (clubsData.length > 0) {
      filterClubs();
    }
  }, [clubsData, userClubs.length]);

  return (
    <div>
      {userClubs.map((obj) => (
        <Club_card key={obj._id} obj={obj} follower={true} buttonVisible={true} role={role} 
        />
      ))}
      {notUserClubs.map((obj) => (
        <Club_card key={obj._id} obj={obj} follower={false} buttonVisible={true} role={role} 
        />
      ))}
    </div>
  );
}

export default Clubs;
