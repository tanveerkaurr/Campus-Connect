import React, { useEffect } from 'react'
import Carousel from 'react-multi-carousel';
import 'react-multi-carousel/lib/styles.css';
import { Typography } from "@material-tailwind/react";
import { Footer, NotificationGrid, Welcome_Carousel, NavbarDefault, Slider } from '../Components';
import { useNavigate } from 'react-router-dom';
import { authController } from '../Services/controllers/AuthController';
import swal from 'sweetalert';

const companies = [
  {
    Name: "Tech Innovators Inc.",
    role: "Software Engineer",
    description: "Developing cutting-edge software solutions for various industries.",
    package: "$100,000 per annum",
    last_date: "2024-05-15",
    reg_link: "https://example.com/apply"
  },
  {
    Name: "Data Dynamics Ltd.",
    role: "Data Analyst",
    description: "Analyzing large datasets to extract valuable insights for business strategies.",
    package: "$80,000 per annum",
    last_date: "2024-05-10",
    reg_link: "https://example.com/apply"
  },
  {
    Name: "EcoTech Solutions",
    role: "Environmental Scientist",
    description: "Researching and implementing eco-friendly technologies for sustainable development.",
    package: "$90,000 per annum",
    last_date: "2024-05-20",
    reg_link: "https://example.com/apply"
  },
  {
    Name: "HealthCare Innovations",
    role: "Medical Researcher",
    description: "Conducting clinical trials and research to develop breakthrough medical treatments.",
    package: "$110,000 per annum",
    last_date: "2024-05-12",
    reg_link: "https://example.com/apply"
  },
  {
    Name: "Finance Forward Ltd.",
    role: "Financial Analyst",
    description: "Analyzing market trends and financial data to provide investment insights.",
    package: "$85,000 per annum",
    last_date: "2024-05-18",
    reg_link: "https://example.com/apply"
  },
  {
    Name: "Artisan Creations Co.",
    role: "Graphic Designer",
    description: "Creating visually appealing designs for marketing and branding purposes.",
    package: "$70,000 per annum",
    last_date: "2024-05-14",
    reg_link: "https://example.com/apply"
  },
  {
    Name: "Energy Solutions Inc.",
    role: "Renewable Energy Engineer",
    description: "Designing and implementing renewable energy systems for sustainable power generation.",
    package: "$95,000 per annum",
    last_date: "2024-05-16",
    reg_link: "https://example.com/apply"
  },
  {
    Name: "Global Logistics Group",
    role: "Supply Chain Manager",
    description: "Optimizing supply chain operations to ensure efficient logistics management.",
    package: "$100,000 per annum",
    last_date: "2024-05-11",
    reg_link: "https://example.com/apply"
  },
  {
    Name: "Education Innovations Institute",
    role: "Educational Researcher",
    description: "Conducting research on innovative teaching methods and educational technologies.",
    package: "$90,000 per annum",
    last_date: "2024-05-17",
    reg_link: "https://example.com/apply"
  },
  {
    Name: "Space Exploration Technologies",
    role: "Aerospace Engineer",
    description: "Designing spacecraft and propulsion systems for space exploration missions.",
    package: "$120,000 per annum",
    last_date: "2024-05-13",
    reg_link: "https://example.com/apply"
  }
];



function Dashstudent() {
  const responsive = {
    superLargeDesktop: {
      // the naming can be any, depends on you.
      breakpoint: { max: 4000, min: 3000 },
      items: 5
    },
    desktop: {
      breakpoint: { max: 3000, min: 1024 },
      items: 4
    },
    tablet: {
      breakpoint: { max: 1024, min: 464 },
      items: 2
    },
    mobile: {
      breakpoint: { max: 464, min: 0 },
      items: 1
    }
  };

  useEffect(()=>{
    // fetch_AllApplications();
  },[])


  // async function fetch_AllApplications{
  //   try{
  //     const response = await get_AllApplications();
  //   }catch(err){
  //     console.log(err)
  //     swal("Error",err.response.data.message||err.response.data.error, "error");
  //   }
  // }


  const navigate = useNavigate();
  const validateUser = async () => {

    const token = localStorage.getItem('token');

    if (token === null) {
        navigate('/');
    }

    try{const response = await authController();
    // console.log(response);
    if(response.data.success===false){
        navigate('/');
    }
    // pending usercheck after validate using token
    }catch(err){
        console.log(err)
        swal("Error",err.response.data.message||err.response.data.error, "error");
    }
   }  
  return (

    <div>
      <Welcome_Carousel></Welcome_Carousel>
      {/* Slider */}
      <div className='bg-BgLightBlack py-3 my-6' >
        <Typography variant='h3' className="flex items-center gap-1 my-6 ms-6  text-xl justify-center">All companies</Typography>
        <div className="overflow-hidden">
          <Carousel responsive={responsive} infinite={true} autoPlaySpeed={2000} keyBoardControl={true} transitionDuration={500} autoPlay={true} pauseOnHover={true} removeArrowOnDeviceType={["tablet", "mobile",]}
            className='m-4'>
            {
              companies.map((c) => {
                return (
                  <Slider data={c}></Slider>
                )
              })
            }
          </Carousel>
        </div>
      </div>
      <Typography variant='h3' className="flex items-center gap-1 mt-12 ms-6 text-xl  justify-center">Notifications</Typography>
      <NotificationGrid></NotificationGrid>



    </div>
  )
}

export default Dashstudent