import React, { useEffect } from 'react'
import { useNavigate } from 'react-router-dom';
import {authController} from '../Services/controllers/AuthController';
import swal from 'sweetalert';

function Club() {
    const navigate=useNavigate();
    const role=localStorage.getItem("role");
    

    if(role==1){
        navigate("/clubs-student")
    }
    else if(role==2)
    {
        // console.log(role);
        navigate("/clubs-admin")
    }

    const validateUser = async () => {

        const token = localStorage.getItem('token');
  
        if (token === null) {
            navigate('/');
        }
  
        try{const response = await authController();
            // console.log(response);
            if(response.data.success===false){
                navigate('/');
            }
            // pending usercheck after validate using token
            }catch(err){
                console.log(err)
                swal("Error",err.response.data.message||err.response.data.error, "error");
            }
    }
      useEffect(()=>{
        validateUser();
      },[])
}

export default Club;