import React, { useEffect } from 'react'
import {
  Card,
  CardHeader,
  Typography,
  CardBody,
  Chip,
  Tabs,
  TabsHeader,
  Tab,
  Button,

} from "@material-tailwind/react";

import { useState } from 'react';
import { AddNotificationModal, AddApplicationModal } from "../Components";
import { PencilIcon } from "@heroicons/react/20/solid";
import { authController } from '../Services/controllers/AuthController';
import { FetchNotifications, DeleteNotification, AddNotification, UpdateNotification } from '../Services/controllers/NotificationController';
// import {} from "../../Services/controllers/NotificationController";
import { DeleteApplication, FetchApplications } from '../Services/controllers/ApplicationController';
import { useNavigate } from 'react-router-dom';
import swal from 'sweetalert';

const ManageNotifications = () => {

  useEffect(() => {
    validateUser();
    handleFetching();
  }, [])



  const [TABLE_ROWS, setTABLE_ROWS] = useState(
    [

      {
        label: "Club",
        value: "Club",
        data: [
          {
            id: 1,
            type: "Club",
            title: "Title",
            message: "Description",
            link: "https://www.google.com"
          }
        ]
      },
      {
        label: "Applications",
        value: "Applications",
        data: [

          {
            id: 1,
            type: "Applications",
            title: "Title",
            message: "Description",
            link: "https://www.google.com"
          }
        ]
      },
      {
        label: "General",
        value: "General",
        data: [
          {
            id: 1,
            type: "General",
            title: "Title",
            message: "Description",
            link: "https://www.google.com"
          }
        ]
      }
    ]
  );

  const [toShow, setToShow] = useState([]);

  const TABS = [
    {
      label: "Club",
      value: "Club",
    },
    {
      label: "Applications",
      value: "Applications",
    },
    {
      label: "General",
      value: "General",
    },
  ];

  const [selectedTab, setSelectedTab] = useState("Club");

  const handleFetching = async () => {
    try {
      const response = await FetchNotifications();
      const response2 = await FetchApplications();

      // console.log(response2.data.applications)
      // console.log(response.data.notifications);

      const data = response.data.notifications;
      const applications = response2.data.applications;

      let tempData = [
        {
          label: "Club",
          value: "Club",
          data: data.filter((row) => row.type === "Club")
        },
        {
          label: "Applications",
          value: "Applications",
          data: applications.map((row) => {
            return {
              title: row.applicationTitle,
              message: row.companyName,
              link: row.applicationLink,
              type: row.applicationType,
              FullLengthData: row,
              _id: row._id
            }
          }),
        },
        {
          label: "General",
          value: "General",
          data: data.filter((row) => row.type === "General")
        }
      ];

      setTABLE_ROWS(tempData);

      setToShow(tempData.find(row => row.value === selectedTab).data);

    } catch (err) {
      console.log(err);
      swal("Error", err.response.data.message || err.response.data.error, "error");
    }
  }

  // enum:["Club" , "Events" , "Applications"  , "General"],


  const TABLE_HEAD = ["Notification", "Type", "More Info", "Edit", "Delete"];


  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const handleOpen = () => setOpen((cur) => !cur);

  const [openApplicationEditor, setOpenApplicationEditor] = useState(false);

  const [EditData, setEditData] = useState({}); // {title:"", message:"", type:"", link:""})

  const [applicationModal, setApplicationModal] = useState(false);
  const handleModal = () => setApplicationModal((cur) => !cur);
  const handleEditModal = () => setOpenApplicationEditor((cur) => !cur);

  const handleDeleteApplication = async ({ index }) => {

    try {
      const response = await DeleteApplication(toShow[index]._id);
      // console.log(response);
      handleFetching();
    } catch (err) {
      console.log(err);
      swal("Error", err.response.data.message || err.response.data.error, "error");
    }
  }

  useEffect(() => {
    handleFetching();
  }, [open, applicationModal, openApplicationEditor])

  const handleDeleteNotification = async ({ index }) => {
    // console.log(toShow[index]);

    try {
      const response = await DeleteNotification(toShow[index]._id);

      handleFetching();
    } catch (err) {
      console.log(err);
      swal("Error", err.response.data.message || err.response.data.error, "error");
    }

  }

  if (open) {// if modal is requested to be opened
    return (
      <AddNotificationModal handleOpen={handleOpen} open={open} setOpen={setOpen} EditData={(EditData.title) ?EditData:{}} setEditData={setEditData} CTA={(EditData.title) ? (UpdateNotification) : (AddNotification)} />
    );
  }

  if (applicationModal) {// if modal is requested to be opened
    return (
      <AddApplicationModal handleOpen={handleModal} open={applicationModal} setOpen={setApplicationModal} />
    )
  }

  if (openApplicationEditor) {// if modal is requested to be opened
    // console.log(EditData.FullLengthData)
    return (
      <AddApplicationModal handleOpen={handleEditModal} open={openApplicationEditor} setOpen={setOpenApplicationEditor} EditorData={EditData.FullLengthData} setEditData={setEditData} Edit={true} />
    )
  }

  const validateUser = async () => {

    const token = localStorage.getItem('token');

    if (token === null) {
      navigate('/');
    }

    try {
      const response = await authController();
      // console.log(response);
      if (response.data.success === false) {
        navigate('/');
      }
      // pending usercheck after validate using token
    } catch (err) {
      console.log(err)
      swal("Error", err.response.data.message || err.response.data.error, "error");
    }
  }


  return (

    <Card className="m-4 p-2">
      <CardHeader floated={false} shadow={false} className="rounded-none">
        <div className="flex flex-col items-center justify-between gap-4 md:flex-row">
          <Tabs value={selectedTab} className=" " >
            <TabsHeader className='flex gap-3'>
              {TABS.map(({ label, value }) => (
                <Tab key={value} value={value}
                  onClick={(e) => {
                    setSelectedTab(value)
                    setToShow(TABLE_ROWS.find(row => row.value === value).data)
                  }}>
                  &nbsp;&nbsp;{label}&nbsp;&nbsp;
                </Tab>
              ))}
            </TabsHeader>
          </Tabs>

          {/* Search Bar */}

          {/* <div className="w-full md:w-72">
          <Input
            label="Search"
            icon={<MagnifyingGlassIcon className="h-5 w-5" />}
          />
        </div> */}

        </div>
      </CardHeader>

      <CardBody className="overflow-scroll px-0">
        <table className="mt-4 w-full min-w-max table-auto text-left" >
          <thead>
            <tr>
              {TABLE_HEAD.map((head) => (
                <th
                  key={head}
                  className="border-y border-blue-gray-100 bg-blue-gray-50/50 p-4 "
                >
                  <Typography
                    variant="small"
                    color="blue-gray"
                    className="font-normal leading-none opacity-70"
                  >
                    {head}
                  </Typography>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {toShow.map(({_id, type, title, message, link, FullLengthData }, index) => {
              const isLast = index === toShow.length - 1;
              let classes = isLast
                ? "p-4"
                : "p-4 border-b border-blue-gray-50";
              let applicationBool = true;
              let detailType = (type == "0" ? "Internship" : type == "1" ? "Job" : type == "2" ? "Training" : type == "3" ? "Workshop" : type);

              if (type === detailType) {
                applicationBool = false;
              }

              const colorScheme = type === "Club" ? "blue" : type === "Applications" ? "yellow" : type === "General" ? "green" : ("orange");


              return (
                <tr key={index}>
                  <td className={classes}>

                    <div className="flex flex-col max-w-16 sm:max-w-48 md:max-w-96 lg:max-w-[1400px]">
                      <Typography
                        variant="small"
                        color="blue-gray"
                        className="font-normal"
                      >
                        {title}
                      </Typography>


                      <Typography
                        variant="small"
                        color="blue-gray"
                        className="font-normal opacity-70 "
                      >
                        {message}
                      </Typography>



                    </div>

                  </td>


                  <td className={`${classes} max-w-28`}>
                    <div className="w-max">
                      <Chip
                        variant="ghost"
                        size="sm"
                        value={detailType}
                        color={colorScheme}
                      />
                    </div>
                  </td>


                  <td className={`${classes} max-w-28`}>
                    <a href={link} target="_blank" rel="noreferrer">
                      <Chip
                        variant="ghost"
                        size="sm"
                        value="Open Link"
                        color="blue-gray"
                        className='w-max hover:border-black hover:text-black'
                      />
                    </a>
                  </td>
                  <td className={`${classes} max-w-28  `}>
                    <PencilIcon
                      className="h-5 w-5 text-blue-gray-500 cursor-pointer hover:text-blue-400"
                      onClick={() => {
                        if (applicationBool) {
                          setOpenApplicationEditor(true)
                          setEditData({_id, title, message, type, link, FullLengthData })
                        }
                        else {
                          setOpen(!open)
                          setEditData({_id, title, message, type, link })
                        }
                        // 
                      }}
                    />
                  </td>
                  <td className={`${classes} max-w-28  `}>
                    <svg xmlns="http://www.w3.org/2000/svg"
                      viewBox="0 0 24 24"
                      fill="currentColor"
                      className="w-6 h-6 hover:text-red-500"
                      onClick={(e) => {

                        // console.log(applicationBool+detailType+type);

                        if (applicationBool) {
                          swal({
                            title: "Are you sure?",
                            text: "Once deleted you will not be able to recover this application!",
                            icon: "warning",
                            buttons: true,
                            dangerMode: true,
                          })
                            .then((willDelete) => {
                              if (willDelete) {
                                // console.log("Helllllo");
                                handleDeleteApplication({ index });
                                swal("Your Application has been deleted!", {
                                  icon: "success",
                                  timer: 2000
                                });
                              } else {
                                swal("Your Application is safe!", {
                                  icon: "info",
                                  timer: 2000

                                });
                              }
                            });
                        }
                        else {
                          swal({
                            title: "Are you sure?",
                            text: "Once deleted you will not be able to recover this notification!",
                            icon: "warning",
                            buttons: true,
                            dangerMode: true,
                          })
                            .then((willDelete) => {
                              if (willDelete) {
                                handleDeleteNotification({ index });
                                swal("Your Notification has been deleted!", {
                                  icon: "success",
                                  timer: 2000
                                });
                              } else {
                                swal("Your Notification is safe!", {
                                  icon: "info",
                                  timer: 2000

                                });
                              }
                            });
                        }
                      }}
                    >
                      <path fillRule="evenodd" d="M16.5 4.478v.227a48.816 48.816 0 0 1 3.878.512.75.75 0 1 1-.256 1.478l-.209-.035-1.005 13.07a3 3 0 0 1-2.991 2.77H8.084a3 3 0 0 1-2.991-2.77L4.087 6.66l-.209.035a.75.75 0 0 1-.256-1.478A48.567 48.567 0 0 1 7.5 4.705v-.227c0-1.564 1.213-2.9 2.816-2.951a52.662 52.662 0 0 1 3.369 0c1.603.051 2.815 1.387 2.815 2.951Zm-6.136-1.452a51.196 51.196 0 0 1 3.273 0C14.39 3.05 15 3.684 15 4.478v.113a49.488 49.488 0 0 0-6 0v-.113c0-.794.609-1.428 1.364-1.452Zm-.355 5.945a.75.75 0 1 0-1.5.058l.347 9a.75.75 0 1 0 1.499-.058l-.346-9Zm5.48.058a.75.75 0 1 0-1.498-.058l-.347 9a.75.75 0 0 0 1.5.058l.345-9Z" clipRule="evenodd" />
                    </svg>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </CardBody>

      <div className='flex justify-center align-middle m-4 p-2  gap-2'>
        {selectedTab !== "Applications" && (
          <Button className='w-64'
            onClick={() => {
              setEditData({})
              setOpen(true)}}
          >
            Add New Notification
          </Button>
        )}

        {selectedTab === "Applications" && (
          <Button className='w-64'
            onClick={() => {
              setEditData({})
              setApplicationModal(true)
            }}
          >
            Add New Application
          </Button>
        )}
      </div>
    </Card>

  );
}

export default ManageNotifications;