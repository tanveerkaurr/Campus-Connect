﻿# Application-Server

# Links
## Developmental at :- http://localhost:5000/
## Production at:-https://tpc-backend-mb3w.onrender.com/ # TPC-Backend
